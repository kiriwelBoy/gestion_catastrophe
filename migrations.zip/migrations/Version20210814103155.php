<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20210814103155 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE surfaces_habitations (id INT AUTO_INCREMENT NOT NULL, type_habit_atteintes VARCHAR(255) NOT NULL, nbre_habit_atteintes INT DEFAULT NULL, nbre_habit_detruites INT DEFAULT NULL, age_moy_habit_atteintes INT DEFAULT NULL, prox_eau TINYINT(1) NOT NULL, type_cours_eau_prox VARCHAR(255) DEFAULT NULL, surfaces_atteintes VARCHAR(255) NOT NULL, surfaces_detruites VARCHAR(255) DEFAULT NULL, type_surf_atteintes VARCHAR(255) NOT NULL, surfaces_cult_atteintes VARCHAR(255) DEFAULT NULL, surfaces_cult_detruites VARCHAR(255) DEFAULT NULL, voies_entre_eau VARCHAR(255) DEFAULT NULL, hauteur_eau VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE usager ADD accident_id INT NOT NULL');
        $this->addSql('ALTER TABLE usager ADD CONSTRAINT FK_3CDC65FF16D8554C FOREIGN KEY (accident_id) REFERENCES accident (id)');
        $this->addSql('CREATE INDEX IDX_3CDC65FF16D8554C ON usager (accident_id)');
        $this->addSql('ALTER TABLE users ADD id_resp_id INT DEFAULT NULL, ADD region VARCHAR(255) DEFAULT NULL, ADD departement VARCHAR(255) DEFAULT NULL');
        $this->addSql('ALTER TABLE users ADD CONSTRAINT FK_1483A5E92C720F44 FOREIGN KEY (id_resp_id) REFERENCES users (id)');
        $this->addSql('CREATE INDEX IDX_1483A5E92C720F44 ON users (id_resp_id)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE innondations DROP FOREIGN KEY FK_C2CD45CA1E08FE59');
        $this->addSql('DROP TABLE surfaces_habitations');
        $this->addSql('ALTER TABLE usager DROP FOREIGN KEY FK_3CDC65FF16D8554C');
        $this->addSql('DROP INDEX IDX_3CDC65FF16D8554C ON usager');
        $this->addSql('ALTER TABLE usager DROP accident_id');
        $this->addSql('ALTER TABLE users DROP FOREIGN KEY FK_1483A5E92C720F44');
        $this->addSql('DROP INDEX IDX_1483A5E92C720F44 ON users');
        $this->addSql('ALTER TABLE users DROP id_resp_id, DROP region, DROP departement');
    }
}
