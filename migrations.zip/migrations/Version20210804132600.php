<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20210804132600 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE accidents (id INT AUTO_INCREMENT NOT NULL, caracteristiques_id INT DEFAULT NULL, lieu_id INT NOT NULL, date DATETIME NOT NULL, nbre_tuees INT DEFAULT NULL, nbre_usagers INT NOT NULL, nbre_blesses INT DEFAULT NULL, nbre_vi INT DEFAULT NULL, UNIQUE INDEX UNIQ_C68C8219B2639FE4 (caracteristiques_id), INDEX IDX_C68C82196AB213CC (lieu_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE accidents ADD CONSTRAINT FK_C68C8219B2639FE4 FOREIGN KEY (caracteristiques_id) REFERENCES caracteristiques (id)');
        $this->addSql('ALTER TABLE accidents ADD CONSTRAINT FK_C68C82196AB213CC FOREIGN KEY (lieu_id) REFERENCES lieu (id)');
        $this->addSql('ALTER TABLE caracteristiques DROP FOREIGN KEY FK_61B5DA1D16D8554C');
        $this->addSql('DROP INDEX UNIQ_61B5DA1D16D8554C ON caracteristiques');
        $this->addSql('ALTER TABLE caracteristiques DROP accident_id');
        $this->addSql('ALTER TABLE usager DROP FOREIGN KEY FK_3CDC65FF16D8554C');
        $this->addSql('DROP INDEX IDX_3CDC65FF16D8554C ON usager');
        $this->addSql('ALTER TABLE usager CHANGE accident_id accidents_id INT NOT NULL');
        $this->addSql('ALTER TABLE usager ADD CONSTRAINT FK_3CDC65FF980D68CB FOREIGN KEY (accidents_id) REFERENCES accidents (id)');
        $this->addSql('CREATE INDEX IDX_3CDC65FF980D68CB ON usager (accidents_id)');
        $this->addSql('ALTER TABLE vehicule DROP FOREIGN KEY FK_292FFF1D16D8554C');
        $this->addSql('DROP INDEX IDX_292FFF1D16D8554C ON vehicule');
        $this->addSql('ALTER TABLE vehicule CHANGE accident_id accidents_id INT NOT NULL');
        $this->addSql('ALTER TABLE vehicule ADD CONSTRAINT FK_292FFF1D980D68CB FOREIGN KEY (accidents_id) REFERENCES accidents (id)');
        $this->addSql('CREATE INDEX IDX_292FFF1D980D68CB ON vehicule (accidents_id)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE usager DROP FOREIGN KEY FK_3CDC65FF980D68CB');
        $this->addSql('ALTER TABLE vehicule DROP FOREIGN KEY FK_292FFF1D980D68CB');
        $this->addSql('DROP TABLE accidents');
        $this->addSql('ALTER TABLE caracteristiques ADD accident_id INT NOT NULL');
        $this->addSql('ALTER TABLE caracteristiques ADD CONSTRAINT FK_61B5DA1D16D8554C FOREIGN KEY (accident_id) REFERENCES accident (id)');
        $this->addSql('CREATE UNIQUE INDEX UNIQ_61B5DA1D16D8554C ON caracteristiques (accident_id)');
        $this->addSql('DROP INDEX IDX_3CDC65FF980D68CB ON usager');
        $this->addSql('ALTER TABLE usager CHANGE accidents_id accident_id INT NOT NULL');
        $this->addSql('ALTER TABLE usager ADD CONSTRAINT FK_3CDC65FF16D8554C FOREIGN KEY (accident_id) REFERENCES accident (id)');
        $this->addSql('CREATE INDEX IDX_3CDC65FF16D8554C ON usager (accident_id)');
        $this->addSql('DROP INDEX IDX_292FFF1D980D68CB ON vehicule');
        $this->addSql('ALTER TABLE vehicule CHANGE accidents_id accident_id INT NOT NULL');
        $this->addSql('ALTER TABLE vehicule ADD CONSTRAINT FK_292FFF1D16D8554C FOREIGN KEY (accident_id) REFERENCES accident (id)');
        $this->addSql('CREATE INDEX IDX_292FFF1D16D8554C ON vehicule (accident_id)');
    }
}
