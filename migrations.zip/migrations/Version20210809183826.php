<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20210809183826 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE autre_degat (id INT AUTO_INCREMENT NOT NULL, poids_vi_det_emp VARCHAR(255) DEFAULT NULL, nbre_anim_perdu INT DEFAULT NULL, type_anim_perdu VARCHAR(255) DEFAULT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE caracteristiques_innondations (id INT AUTO_INCREMENT NOT NULL, volumetrie DOUBLE PRECISION NOT NULL, type_innon VARCHAR(255) NOT NULL, date DATETIME NOT NULL, cause VARCHAR(255) NOT NULL, region VARCHAR(255) NOT NULL, departement VARCHAR(255) NOT NULL, commune VARCHAR(255) NOT NULL, ville VARCHAR(255) DEFAULT NULL, village VARCHAR(255) DEFAULT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE menages_personnes (id INT AUTO_INCREMENT NOT NULL, nbre_men_atteints INT DEFAULT NULL, nbre_men_sinistre INT DEFAULT NULL, nbre_morts INT DEFAULT NULL, nbre_blesse INT DEFAULT NULL, nbre_sinistre INT DEFAULT NULL, nbre_victimes INT DEFAULT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE surfaces_habitations (id INT AUTO_INCREMENT NOT NULL, type_habit_atteintes VARCHAR(255) NOT NULL, nbre_habit_atteintes INT DEFAULT NULL, nbre_habit_d�truites INT DEFAULT NULL, age_moy_habit_atteintes INT DEFAULT NULL, prox_eau TINYINT(1) NOT NULL, type_cours_eau_prox VARCHAR(255) DEFAULT NULL, surfaces_atteintes VARCHAR(255) NOT NULL, surfaces_detruites VARCHAR(255) DEFAULT NULL, type_surf_atteintes VARCHAR(255) NOT NULL, surfaces_cult_atteintes VARCHAR(255) DEFAULT NULL, surfaces_cult_detruites VARCHAR(255) DEFAULT NULL, voies_entre_eau VARCHAR(255) DEFAULT NULL, hauteur_eau VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE innondations DROP FOREIGN KEY FK_C2CD45CA3D444FD0');
        $this->addSql('ALTER TABLE innondations DROP FOREIGN KEY FK_C2CD45CAB2639FE4');
        $this->addSql('ALTER TABLE innondations DROP FOREIGN KEY FK_C2CD45CAAB69D7BC');
        $this->addSql('ALTER TABLE innondations DROP FOREIGN KEY FK_C2CD45CA1E08FE59');
        $this->addSql('DROP TABLE autre_degat');
        $this->addSql('DROP TABLE caracteristiques_innondations');
        $this->addSql('DROP TABLE menages_personnes');
        $this->addSql('DROP TABLE surfaces_habitations');
    }
}
