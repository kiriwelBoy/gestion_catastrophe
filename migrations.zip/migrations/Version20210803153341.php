<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20210803153341 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE accident (id INT AUTO_INCREMENT NOT NULL, id_lieu_id INT NOT NULL, date DATETIME NOT NULL, nombre_de_personnes_tuees INT DEFAULT NULL, nombre_usagers INT NOT NULL, nombre_de_blesses INT DEFAULT NULL, nombre_vehicules_impliques INT DEFAULT NULL, INDEX IDX_8F31DB6FB42FBABC (id_lieu_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE caracteristiques (id INT AUTO_INCREMENT NOT NULL, accident_id INT NOT NULL, jour INT NOT NULL, mois INT NOT NULL, annee INT NOT NULL, heure INT NOT NULL, minutes INT NOT NULL, luminiosite VARCHAR(255) NOT NULL, departement VARCHAR(255) NOT NULL, commune VARCHAR(255) NOT NULL, agglomeration TINYINT(1) NOT NULL, intersection VARCHAR(255) DEFAULT NULL, atm VARCHAR(255) NOT NULL, collision VARCHAR(255) DEFAULT NULL, adresse VARCHAR(255) NOT NULL, latitude DOUBLE PRECISION NOT NULL, longitude DOUBLE PRECISION NOT NULL, UNIQUE INDEX UNIQ_61B5DA1D16D8554C (accident_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE compte_admin (id INT AUTO_INCREMENT NOT NULL, matricule VARCHAR(255) NOT NULL, nom VARCHAR(255) NOT NULL, prenom VARCHAR(255) NOT NULL, adresse VARCHAR(255) NOT NULL, email VARCHAR(255) NOT NULL, mot_de_passe VARCHAR(255) NOT NULL, telephone INT NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE compte_agent (id INT AUTO_INCREMENT NOT NULL, compte_moderateur_id INT NOT NULL, matricule VARCHAR(255) NOT NULL, nom VARCHAR(255) NOT NULL, prenom VARCHAR(255) NOT NULL, adresse VARCHAR(255) NOT NULL, email VARCHAR(255) NOT NULL, mot_de_passe VARCHAR(255) NOT NULL, telephone INT NOT NULL, status_compte VARCHAR(255) NOT NULL, INDEX IDX_DF6A7BF6F31AC107 (compte_moderateur_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE compte_moderateur (id INT AUTO_INCREMENT NOT NULL, compte_admin_id INT NOT NULL, matricule VARCHAR(255) NOT NULL, nom VARCHAR(255) NOT NULL, prenom VARCHAR(255) NOT NULL, adresse VARCHAR(255) NOT NULL, email VARCHAR(255) NOT NULL, mot_de_passe VARCHAR(255) NOT NULL, telephone INT NOT NULL, status_compte VARCHAR(255) NOT NULL, INDEX IDX_A5C8EAEAE69B11ED (compte_admin_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE compte_rendu (id INT AUTO_INCREMENT NOT NULL, compte_admin_id INT NOT NULL, compte_moderateur_id INT NOT NULL, compte_agent_id INT NOT NULL, type_compte_rendu VARCHAR(255) NOT NULL, statut VARCHAR(255) NOT NULL, commentaires LONGTEXT DEFAULT NULL, INDEX IDX_D39E69D2E69B11ED (compte_admin_id), INDEX IDX_D39E69D2F31AC107 (compte_moderateur_id), INDEX IDX_D39E69D2B6A4E2F6 (compte_agent_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE lieu (id INT AUTO_INCREMENT NOT NULL, categorie VARCHAR(255) NOT NULL, voie VARCHAR(255) NOT NULL, circulation VARCHAR(255) NOT NULL, nombre_voiture INT DEFAULT NULL, voie_speciale TINYINT(1) NOT NULL, profil VARCHAR(255) NOT NULL, pr INT NOT NULL, pr1 INT NOT NULL, plan VARCHAR(255) NOT NULL, largeur_terre_plein INT DEFAULT NULL, largeur_chausee INT DEFAULT NULL, surface VARCHAR(255) NOT NULL, ainfrastructure VARCHAR(255) NOT NULL, situation_acci VARCHAR(255) NOT NULL, vmax INT DEFAULT NULL, point_ecole TINYINT(1) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE notifications (id INT AUTO_INCREMENT NOT NULL, compte_rendu_id INT DEFAULT NULL, date DATETIME NOT NULL, INDEX IDX_6000B0D34BC44A10 (compte_rendu_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE usager (id INT AUTO_INCREMENT NOT NULL, accident_id INT NOT NULL, immatriculation_vehicule VARCHAR(255) DEFAULT NULL, cat_usager VARCHAR(255) NOT NULL, gravite_blessure VARCHAR(255) NOT NULL, sexe VARCHAR(255) NOT NULL, an_naissance DATE NOT NULL, motif_deplacement VARCHAR(255) NOT NULL, equipement_securite1 VARCHAR(255) DEFAULT NULL, equipement_securite2 VARCHAR(255) DEFAULT NULL, loc_pieton VARCHAR(255) NOT NULL, action_pieton VARCHAR(255) DEFAULT NULL, etat_pieton VARCHAR(255) NOT NULL, INDEX IDX_3CDC65FF16D8554C (accident_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE vehicule (id INT AUTO_INCREMENT NOT NULL, accident_id INT NOT NULL, immatriculation_vehicule VARCHAR(255) NOT NULL, sens_circulation VARCHAR(255) NOT NULL, cat_vehicule VARCHAR(255) NOT NULL, nombre_de_place INT NOT NULL, obstacle_fixe_heurte VARCHAR(255) NOT NULL, obstacle_mobile_heurte VARCHAR(255) NOT NULL, choc VARCHAR(255) NOT NULL, manoeuvre VARCHAR(255) NOT NULL, nombre_occupants INT NOT NULL, INDEX IDX_292FFF1D16D8554C (accident_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE accident ADD CONSTRAINT FK_8F31DB6FB42FBABC FOREIGN KEY (id_lieu_id) REFERENCES lieu (id)');
        $this->addSql('ALTER TABLE caracteristiques ADD CONSTRAINT FK_61B5DA1D16D8554C FOREIGN KEY (accident_id) REFERENCES accident (id)');
        $this->addSql('ALTER TABLE compte_agent ADD CONSTRAINT FK_DF6A7BF6F31AC107 FOREIGN KEY (compte_moderateur_id) REFERENCES compte_moderateur (id)');
        $this->addSql('ALTER TABLE compte_moderateur ADD CONSTRAINT FK_A5C8EAEAE69B11ED FOREIGN KEY (compte_admin_id) REFERENCES compte_admin (id)');
        $this->addSql('ALTER TABLE compte_rendu ADD CONSTRAINT FK_D39E69D2E69B11ED FOREIGN KEY (compte_admin_id) REFERENCES compte_admin (id)');
        $this->addSql('ALTER TABLE compte_rendu ADD CONSTRAINT FK_D39E69D2F31AC107 FOREIGN KEY (compte_moderateur_id) REFERENCES compte_moderateur (id)');
        $this->addSql('ALTER TABLE compte_rendu ADD CONSTRAINT FK_D39E69D2B6A4E2F6 FOREIGN KEY (compte_agent_id) REFERENCES compte_agent (id)');
        $this->addSql('ALTER TABLE notifications ADD CONSTRAINT FK_6000B0D34BC44A10 FOREIGN KEY (compte_rendu_id) REFERENCES compte_rendu (id)');
        $this->addSql('ALTER TABLE usager ADD CONSTRAINT FK_3CDC65FF16D8554C FOREIGN KEY (accident_id) REFERENCES accident (id)');
        $this->addSql('ALTER TABLE vehicule ADD CONSTRAINT FK_292FFF1D16D8554C FOREIGN KEY (accident_id) REFERENCES accident (id)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE caracteristiques DROP FOREIGN KEY FK_61B5DA1D16D8554C');
        $this->addSql('ALTER TABLE usager DROP FOREIGN KEY FK_3CDC65FF16D8554C');
        $this->addSql('ALTER TABLE vehicule DROP FOREIGN KEY FK_292FFF1D16D8554C');
        $this->addSql('ALTER TABLE compte_moderateur DROP FOREIGN KEY FK_A5C8EAEAE69B11ED');
        $this->addSql('ALTER TABLE compte_rendu DROP FOREIGN KEY FK_D39E69D2E69B11ED');
        $this->addSql('ALTER TABLE compte_rendu DROP FOREIGN KEY FK_D39E69D2B6A4E2F6');
        $this->addSql('ALTER TABLE compte_agent DROP FOREIGN KEY FK_DF6A7BF6F31AC107');
        $this->addSql('ALTER TABLE compte_rendu DROP FOREIGN KEY FK_D39E69D2F31AC107');
        $this->addSql('ALTER TABLE notifications DROP FOREIGN KEY FK_6000B0D34BC44A10');
        $this->addSql('ALTER TABLE accident DROP FOREIGN KEY FK_8F31DB6FB42FBABC');
        $this->addSql('DROP TABLE accident');
        $this->addSql('DROP TABLE caracteristiques');
        $this->addSql('DROP TABLE compte_admin');
        $this->addSql('DROP TABLE compte_agent');
        $this->addSql('DROP TABLE compte_moderateur');
        $this->addSql('DROP TABLE compte_rendu');
        $this->addSql('DROP TABLE lieu');
        $this->addSql('DROP TABLE notifications');
        $this->addSql('DROP TABLE usager');
        $this->addSql('DROP TABLE vehicule');
    }
}
