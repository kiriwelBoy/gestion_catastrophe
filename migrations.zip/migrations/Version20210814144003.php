<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20210814144003 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE caracteristiques ADD date_accident DATE NOT NULL, DROP jour, DROP mois, DROP annee, DROP minutes, CHANGE heure heure TIME NOT NULL, CHANGE agglomeration agglomeration VARCHAR(255) NOT NULL');
        $this->addSql('ALTER TABLE lieu ADD num_route VARCHAR(255) NOT NULL, ADD regime_circ VARCHAR(255) NOT NULL, ADD categprie_route VARCHAR(255) NOT NULL, ADD nb_tot_voie INT NOT NULL, ADD signale VARCHAR(255) NOT NULL, ADD profile VARCHAR(255) NOT NULL, ADD num_pr VARCHAR(255) NOT NULL, ADD distance VARCHAR(255) NOT NULL, ADD trace_plan VARCHAR(255) NOT NULL, ADD largeur VARCHAR(255) NOT NULL, ADD largeur1 VARCHAR(255) NOT NULL, ADD etat_surface VARCHAR(255) NOT NULL, ADD amenagement VARCHAR(255) NOT NULL, ADD situation VARCHAR(255) NOT NULL, DROP categorie, DROP voie, DROP circulation, DROP nombre_voiture, DROP voie_speciale, DROP profil, DROP pr, DROP pr1, DROP plan, DROP largeur_terre_plein, DROP largeur_chausee, DROP surface, DROP ainfrastructure, DROP situation_acci, DROP point_ecole, CHANGE vmax vmax INT NOT NULL');
        $this->addSql('ALTER TABLE usager ADD position_usager VARCHAR(255) NOT NULL, ADD categorie VARCHAR(255) NOT NULL, ADD annee_naiss VARCHAR(4) NOT NULL, ADD equipement_secu1 VARCHAR(255) NOT NULL, ADD equipement_secu2 VARCHAR(255) NOT NULL, DROP immatriculation_vehicule, DROP an_naissance, DROP equipement_securite1, DROP equipement_securite2, CHANGE sexe sexe VARCHAR(10) NOT NULL, CHANGE action_pieton action_pieton VARCHAR(255) NOT NULL, CHANGE cat_usager numero_matricule VARCHAR(255) NOT NULL');
        $this->addSql('ALTER TABLE vehicule DROP FOREIGN KEY FK_292FFF1D980D68CB');
        $this->addSql('DROP INDEX IDX_292FFF1D980D68CB ON vehicule');
        $this->addSql('ALTER TABLE vehicule ADD numero_matricule VARCHAR(255) NOT NULL, ADD categ_vehicule VARCHAR(255) NOT NULL, ADD obstacle_fixe VARCHAR(255) NOT NULL, ADD obstacle_mobile VARCHAR(255) NOT NULL, ADD man_oeuvre VARCHAR(255) NOT NULL, ADD nbre_occupant INT NOT NULL, DROP accidents_id, DROP immatriculation_vehicule, DROP cat_vehicule, DROP nombre_de_place, DROP obstacle_fixe_heurte, DROP obstacle_mobile_heurte, DROP manoeuvre, DROP nombre_occupants');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE caracteristiques ADD jour INT NOT NULL, ADD mois INT NOT NULL, ADD annee INT NOT NULL, ADD minutes INT NOT NULL, DROP date_accident, CHANGE heure heure INT NOT NULL, CHANGE agglomeration agglomeration TINYINT(1) NOT NULL');
        $this->addSql('ALTER TABLE lieu ADD categorie VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, ADD voie VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, ADD circulation VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, ADD nombre_voiture INT DEFAULT NULL, ADD voie_speciale TINYINT(1) NOT NULL, ADD profil VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, ADD pr1 INT NOT NULL, ADD plan VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, ADD largeur_terre_plein INT DEFAULT NULL, ADD largeur_chausee INT DEFAULT NULL, ADD surface VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, ADD ainfrastructure VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, ADD situation_acci VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, ADD point_ecole TINYINT(1) NOT NULL, DROP num_route, DROP regime_circ, DROP categprie_route, DROP signale, DROP profile, DROP num_pr, DROP distance, DROP trace_plan, DROP largeur, DROP largeur1, DROP etat_surface, DROP amenagement, DROP situation, CHANGE vmax vmax INT DEFAULT NULL, CHANGE nb_tot_voie pr INT NOT NULL');
        $this->addSql('ALTER TABLE usager ADD immatriculation_vehicule VARCHAR(255) CHARACTER SET utf8mb4 DEFAULT NULL COLLATE `utf8mb4_unicode_ci`, ADD cat_usager VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, ADD an_naissance DATE NOT NULL, ADD equipement_securite1 VARCHAR(255) CHARACTER SET utf8mb4 DEFAULT NULL COLLATE `utf8mb4_unicode_ci`, ADD equipement_securite2 VARCHAR(255) CHARACTER SET utf8mb4 DEFAULT NULL COLLATE `utf8mb4_unicode_ci`, DROP numero_matricule, DROP position_usager, DROP categorie, DROP annee_naiss, DROP equipement_secu1, DROP equipement_secu2, CHANGE sexe sexe VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, CHANGE action_pieton action_pieton VARCHAR(255) CHARACTER SET utf8mb4 DEFAULT NULL COLLATE `utf8mb4_unicode_ci`');
        $this->addSql('ALTER TABLE vehicule ADD immatriculation_vehicule VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, ADD cat_vehicule VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, ADD nombre_de_place INT NOT NULL, ADD obstacle_fixe_heurte VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, ADD obstacle_mobile_heurte VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, ADD manoeuvre VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL COLLATE `utf8mb4_unicode_ci`, ADD nombre_occupants INT NOT NULL, DROP numero_matricule, DROP categ_vehicule, DROP obstacle_fixe, DROP obstacle_mobile, DROP man_oeuvre, CHANGE nbre_occupant accidents_id INT NOT NULL');
        $this->addSql('ALTER TABLE vehicule ADD CONSTRAINT FK_292FFF1D980D68CB FOREIGN KEY (accidents_id) REFERENCES accidents (id)');
        $this->addSql('CREATE INDEX IDX_292FFF1D980D68CB ON vehicule (accidents_id)');
    }
}
