<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20210804195652 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE accident DROP FOREIGN KEY FK_8F31DB6FB42FBABC');
        $this->addSql('DROP INDEX IDX_8F31DB6FB42FBABC ON accident');
        $this->addSql('ALTER TABLE accident ADD caracteristiques_id INT NOT NULL, ADD lieu_id INT NOT NULL, ADD user_id INT NOT NULL, ADD nbre_tuees INT DEFAULT NULL, ADD nbre_usagers INT NOT NULL, ADD nbre_blesses INT DEFAULT NULL, ADD nbre_vi INT NOT NULL, DROP id_lieu_id, DROP nombre_de_personnes_tuees, DROP nombre_usagers, DROP nombre_de_blesses, DROP nombre_vehicules_impliques');
        $this->addSql('ALTER TABLE accident ADD CONSTRAINT FK_8F31DB6FB2639FE4 FOREIGN KEY (caracteristiques_id) REFERENCES caracteristiques (id)');
        $this->addSql('ALTER TABLE accident ADD CONSTRAINT FK_8F31DB6F6AB213CC FOREIGN KEY (lieu_id) REFERENCES lieu (id)');
        $this->addSql('ALTER TABLE accident ADD CONSTRAINT FK_8F31DB6FA76ED395 FOREIGN KEY (user_id) REFERENCES users (id)');
        $this->addSql('CREATE UNIQUE INDEX UNIQ_8F31DB6FB2639FE4 ON accident (caracteristiques_id)');
        $this->addSql('CREATE INDEX IDX_8F31DB6F6AB213CC ON accident (lieu_id)');
        $this->addSql('CREATE INDEX IDX_8F31DB6FA76ED395 ON accident (user_id)');
        $this->addSql('ALTER TABLE commentaires ADD accident_id INT NOT NULL');
        $this->addSql('ALTER TABLE commentaires ADD CONSTRAINT FK_D9BEC0C416D8554C FOREIGN KEY (accident_id) REFERENCES accident (id)');
        $this->addSql('CREATE INDEX IDX_D9BEC0C416D8554C ON commentaires (accident_id)');
        $this->addSql('ALTER TABLE usager ADD accident_id INT NOT NULL');
        $this->addSql('ALTER TABLE usager ADD CONSTRAINT FK_3CDC65FF16D8554C FOREIGN KEY (accident_id) REFERENCES accident (id)');
        $this->addSql('CREATE INDEX IDX_3CDC65FF16D8554C ON usager (accident_id)');
        $this->addSql('ALTER TABLE vehicule ADD accident_id INT NOT NULL');
        $this->addSql('ALTER TABLE vehicule ADD CONSTRAINT FK_292FFF1D16D8554C FOREIGN KEY (accident_id) REFERENCES accident (id)');
        $this->addSql('CREATE INDEX IDX_292FFF1D16D8554C ON vehicule (accident_id)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE accident DROP FOREIGN KEY FK_8F31DB6FB2639FE4');
        $this->addSql('ALTER TABLE accident DROP FOREIGN KEY FK_8F31DB6F6AB213CC');
        $this->addSql('ALTER TABLE accident DROP FOREIGN KEY FK_8F31DB6FA76ED395');
        $this->addSql('DROP INDEX UNIQ_8F31DB6FB2639FE4 ON accident');
        $this->addSql('DROP INDEX IDX_8F31DB6F6AB213CC ON accident');
        $this->addSql('DROP INDEX IDX_8F31DB6FA76ED395 ON accident');
        $this->addSql('ALTER TABLE accident ADD id_lieu_id INT NOT NULL, ADD nombre_de_personnes_tuees INT DEFAULT NULL, ADD nombre_usagers INT NOT NULL, ADD nombre_de_blesses INT DEFAULT NULL, ADD nombre_vehicules_impliques INT DEFAULT NULL, DROP caracteristiques_id, DROP lieu_id, DROP user_id, DROP nbre_tuees, DROP nbre_usagers, DROP nbre_blesses, DROP nbre_vi');
        $this->addSql('ALTER TABLE accident ADD CONSTRAINT FK_8F31DB6FB42FBABC FOREIGN KEY (id_lieu_id) REFERENCES lieu (id)');
        $this->addSql('CREATE INDEX IDX_8F31DB6FB42FBABC ON accident (id_lieu_id)');
        $this->addSql('ALTER TABLE commentaires DROP FOREIGN KEY FK_D9BEC0C416D8554C');
        $this->addSql('DROP INDEX IDX_D9BEC0C416D8554C ON commentaires');
        $this->addSql('ALTER TABLE commentaires DROP accident_id');
        $this->addSql('ALTER TABLE usager DROP FOREIGN KEY FK_3CDC65FF16D8554C');
        $this->addSql('DROP INDEX IDX_3CDC65FF16D8554C ON usager');
        $this->addSql('ALTER TABLE usager DROP accident_id');
        $this->addSql('ALTER TABLE vehicule DROP FOREIGN KEY FK_292FFF1D16D8554C');
        $this->addSql('DROP INDEX IDX_292FFF1D16D8554C ON vehicule');
        $this->addSql('ALTER TABLE vehicule DROP accident_id');
    }
}
