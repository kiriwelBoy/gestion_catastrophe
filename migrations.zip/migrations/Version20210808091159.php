<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20210808091159 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('DROP TABLE accidents_users');
        $this->addSql('ALTER TABLE accidents ADD user_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE accidents ADD CONSTRAINT FK_C68C8219A76ED395 FOREIGN KEY (user_id) REFERENCES users (id)');
        $this->addSql('CREATE INDEX IDX_C68C8219A76ED395 ON accidents (user_id)');
        $this->addSql('ALTER TABLE usager DROP FOREIGN KEY FK_3CDC65FF16D8554C');
        $this->addSql('ALTER TABLE usager DROP FOREIGN KEY FK_3CDC65FF980D68CB');
        $this->addSql('DROP INDEX IDX_3CDC65FF16D8554C ON usager');
        $this->addSql('DROP INDEX IDX_3CDC65FF980D68CB ON usager');
        $this->addSql('ALTER TABLE usager DROP accidents_id, DROP accident_id');
        $this->addSql('ALTER TABLE users ADD id_resp INT DEFAULT NULL');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE accidents_users (accidents_id INT NOT NULL, users_id INT NOT NULL, INDEX IDX_43E91AA5980D68CB (accidents_id), INDEX IDX_43E91AA567B3B43D (users_id), PRIMARY KEY(accidents_id, users_id)) DEFAULT CHARACTER SET utf8 COLLATE `utf8_unicode_ci` ENGINE = InnoDB COMMENT = \'\' ');
        $this->addSql('ALTER TABLE accidents_users ADD CONSTRAINT FK_43E91AA567B3B43D FOREIGN KEY (users_id) REFERENCES users (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE accidents_users ADD CONSTRAINT FK_43E91AA5980D68CB FOREIGN KEY (accidents_id) REFERENCES accidents (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE accidents DROP FOREIGN KEY FK_C68C8219A76ED395');
        $this->addSql('DROP INDEX IDX_C68C8219A76ED395 ON accidents');
        $this->addSql('ALTER TABLE accidents DROP user_id');
        $this->addSql('ALTER TABLE usager ADD accidents_id INT NOT NULL, ADD accident_id INT NOT NULL');
        $this->addSql('ALTER TABLE usager ADD CONSTRAINT FK_3CDC65FF16D8554C FOREIGN KEY (accident_id) REFERENCES accident (id)');
        $this->addSql('ALTER TABLE usager ADD CONSTRAINT FK_3CDC65FF980D68CB FOREIGN KEY (accidents_id) REFERENCES accidents (id)');
        $this->addSql('CREATE INDEX IDX_3CDC65FF16D8554C ON usager (accident_id)');
        $this->addSql('CREATE INDEX IDX_3CDC65FF980D68CB ON usager (accidents_id)');
        $this->addSql('ALTER TABLE users DROP id_resp');
    }
}
