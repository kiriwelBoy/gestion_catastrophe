<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20210809162338 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE caracteristiques_incendies (id INT AUTO_INCREMENT NOT NULL, longitude DOUBLE PRECISION NOT NULL, latitude DOUBLE PRECISION NOT NULL, heure_debut TIME NOT NULL, heure_fin TIME NOT NULL, type_feu VARCHAR(255) NOT NULL, date_debut DATE NOT NULL, date_fin DATE NOT NULL, region VARCHAR(255) NOT NULL, departement VARCHAR(255) NOT NULL, commune VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE don_meteo (id INT AUTO_INCREMENT NOT NULL, vitesse_vent VARCHAR(255) NOT NULL, temperature_lieu VARCHAR(255) NOT NULL, humidite_atmos VARCHAR(255) NOT NULL, direction_vent VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE incendie (id INT AUTO_INCREMENT NOT NULL, caracteristique_id INT NOT NULL, donnee_meteo_id INT NOT NULL, infospatiale_id INT NOT NULL, info_temp_interv_id INT NOT NULL, user_id INT NOT NULL, UNIQUE INDEX UNIQ_B37D707D1704EEB7 (caracteristique_id), UNIQUE INDEX UNIQ_B37D707DE24C901C (donnee_meteo_id), UNIQUE INDEX UNIQ_B37D707DB63E9249 (infospatiale_id), UNIQUE INDEX UNIQ_B37D707DE96C31EA (info_temp_interv_id), INDEX IDX_B37D707DA76ED395 (user_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE info_spatiale (id INT AUTO_INCREMENT NOT NULL, surface_parcourue VARCHAR(255) NOT NULL, dommage_causes VARCHAR(255) NOT NULL, cause_presume VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE info_temp_interv (id INT AUTO_INCREMENT NOT NULL, date_prem_alerte DATE NOT NULL, heure_prem_alerte TIME NOT NULL, auteur_alerte VARCHAR(255) NOT NULL, date_arriv_prem_inter DATE NOT NULL, heure_arriv_prem_inter TIME NOT NULL, date_fin_inter DATE NOT NULL, heure_fin_inter TIME NOT NULL, distance VARCHAR(255) NOT NULL, distance_arret VARCHAR(255) NOT NULL, surface_feu_arriv VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE incendie ADD CONSTRAINT FK_B37D707D1704EEB7 FOREIGN KEY (caracteristique_id) REFERENCES caracteristiques_incendies (id)');
        $this->addSql('ALTER TABLE incendie ADD CONSTRAINT FK_B37D707DE24C901C FOREIGN KEY (donnee_meteo_id) REFERENCES don_meteo (id)');
        $this->addSql('ALTER TABLE incendie ADD CONSTRAINT FK_B37D707DB63E9249 FOREIGN KEY (infospatiale_id) REFERENCES info_spatiale (id)');
        $this->addSql('ALTER TABLE incendie ADD CONSTRAINT FK_B37D707DE96C31EA FOREIGN KEY (info_temp_interv_id) REFERENCES info_temp_interv (id)');
        $this->addSql('ALTER TABLE incendie ADD CONSTRAINT FK_B37D707DA76ED395 FOREIGN KEY (user_id) REFERENCES users (id)');
        $this->addSql('ALTER TABLE commentaires ADD incendie_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE commentaires ADD CONSTRAINT FK_D9BEC0C43BE34AF7 FOREIGN KEY (incendie_id) REFERENCES incendie (id)');
        $this->addSql('CREATE INDEX IDX_D9BEC0C43BE34AF7 ON commentaires (incendie_id)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE incendie DROP FOREIGN KEY FK_B37D707D1704EEB7');
        $this->addSql('ALTER TABLE incendie DROP FOREIGN KEY FK_B37D707DE24C901C');
        $this->addSql('ALTER TABLE commentaires DROP FOREIGN KEY FK_D9BEC0C43BE34AF7');
        $this->addSql('ALTER TABLE incendie DROP FOREIGN KEY FK_B37D707DB63E9249');
        $this->addSql('ALTER TABLE incendie DROP FOREIGN KEY FK_B37D707DE96C31EA');
        $this->addSql('DROP TABLE caracteristiques_incendies');
        $this->addSql('DROP TABLE don_meteo');
        $this->addSql('DROP TABLE incendie');
        $this->addSql('DROP TABLE info_spatiale');
        $this->addSql('DROP TABLE info_temp_interv');
        $this->addSql('DROP INDEX IDX_D9BEC0C43BE34AF7 ON commentaires');
        $this->addSql('ALTER TABLE commentaires DROP incendie_id');
    }
}
