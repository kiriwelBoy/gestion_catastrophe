<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20210804141001 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE accidents_users (accidents_id INT NOT NULL, users_id INT NOT NULL, INDEX IDX_43E91AA5980D68CB (accidents_id), INDEX IDX_43E91AA567B3B43D (users_id), PRIMARY KEY(accidents_id, users_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE accidents_users ADD CONSTRAINT FK_43E91AA5980D68CB FOREIGN KEY (accidents_id) REFERENCES accidents (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE accidents_users ADD CONSTRAINT FK_43E91AA567B3B43D FOREIGN KEY (users_id) REFERENCES users (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE accidents DROP FOREIGN KEY FK_C68C8219B2639FE4');
        $this->addSql('DROP INDEX UNIQ_C68C8219B2639FE4 ON accidents');
        $this->addSql('ALTER TABLE accidents ADD carateristiques_id INT NOT NULL, DROP caracteristiques_id, CHANGE nbre_vi nbre_vi INT NOT NULL');
        $this->addSql('ALTER TABLE accidents ADD CONSTRAINT FK_C68C8219E1DC17D4 FOREIGN KEY (carateristiques_id) REFERENCES caracteristiques (id)');
        $this->addSql('CREATE UNIQUE INDEX UNIQ_C68C8219E1DC17D4 ON accidents (carateristiques_id)');
        $this->addSql('ALTER TABLE commentaires ADD accidents_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE commentaires ADD CONSTRAINT FK_D9BEC0C4980D68CB FOREIGN KEY (accidents_id) REFERENCES accidents (id)');
        $this->addSql('CREATE INDEX IDX_D9BEC0C4980D68CB ON commentaires (accidents_id)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('DROP TABLE accidents_users');
        $this->addSql('ALTER TABLE accidents DROP FOREIGN KEY FK_C68C8219E1DC17D4');
        $this->addSql('DROP INDEX UNIQ_C68C8219E1DC17D4 ON accidents');
        $this->addSql('ALTER TABLE accidents ADD caracteristiques_id INT DEFAULT NULL, DROP carateristiques_id, CHANGE nbre_vi nbre_vi INT DEFAULT NULL');
        $this->addSql('ALTER TABLE accidents ADD CONSTRAINT FK_C68C8219B2639FE4 FOREIGN KEY (caracteristiques_id) REFERENCES caracteristiques (id)');
        $this->addSql('CREATE UNIQUE INDEX UNIQ_C68C8219B2639FE4 ON accidents (caracteristiques_id)');
        $this->addSql('ALTER TABLE commentaires DROP FOREIGN KEY FK_D9BEC0C4980D68CB');
        $this->addSql('DROP INDEX IDX_D9BEC0C4980D68CB ON commentaires');
        $this->addSql('ALTER TABLE commentaires DROP accidents_id');
    }
}
