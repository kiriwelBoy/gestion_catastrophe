<?php

namespace App\Repository\Incendie;

use App\Entity\Incendie\Incendie;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @method Incendie|null find($id, $lockMode = null, $lockVersion = null)
 * @method Incendie|null findOneBy(array $criteria, array $orderBy = null)
 * @method Incendie[]    findAll()
 * @method Incendie[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class IncendieRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Incendie::class);
    }

    // /**
    //  * @return Incendie[] Returns an array of Incendie objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('i')
            ->andWhere('i.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('i.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?Incendie
    {
        return $this->createQueryBuilder('i')
            ->andWhere('i.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
