<?php

namespace App\Entity\User;

use App\Entity\Accident\Accident;
use App\Entity\Incendie\Incendie;
use App\Repository\User\UserRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=UserRepository::class)
 */
class User
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $matricule;

    /**
     * @ORM\Column(type="string", length=60)
     */
    private $nom;

    /**
     * @ORM\Column(type="string", length=100)
     */
    private $prenom;

    /**
     * @ORM\Column(type="string", length=100)
     */
    private $adresse;

    /**
     * @ORM\Column(type="string", length=50)
     */
    private $email;

    /**
     * @ORM\Column(type="string", length=30)
     */
    private $password;

    /**
     * @ORM\Column(type="integer")
     */
    private $telephone;

    /**
     * @ORM\Column(type="string", length=30)
     */
    private $typeCompte;

    /**
     * @ORM\Column(type="string", length=15)
     */
    private $statusCompte;

    /**
     * @ORM\OneToMany(targetEntity=Accident::class, mappedBy="user")
     */
    private $accidents;

    /**
     * @ORM\OneToMany(targetEntity=Incendie::class, mappedBy="user")
     */
    private $incendies;

    public function __construct()
    {
        $this->accidents = new ArrayCollection();
        $this->incendies = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getMatricule(): ?string
    {
        return $this->matricule;
    }

    public function setMatricule(string $matricule): self
    {
        $this->matricule = $matricule;

        return $this;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    public function getPrenom(): ?string
    {
        return $this->prenom;
    }

    public function setPrenom(string $prenom): self
    {
        $this->prenom = $prenom;

        return $this;
    }

    public function getAdresse(): ?string
    {
        return $this->adresse;
    }

    public function setAdresse(string $adresse): self
    {
        $this->adresse = $adresse;

        return $this;
    }

    public function getEmail(): ?string
    {
        return $this->email;
    }

    public function setEmail(string $email): self
    {
        $this->email = $email;

        return $this;
    }

    public function getPassword(): ?string
    {
        return $this->password;
    }

    public function setPassword(string $password): self
    {
        $this->password = $password;

        return $this;
    }

    public function getTelephone(): ?int
    {
        return $this->telephone;
    }

    public function setTelephone(int $telephone): self
    {
        $this->telephone = $telephone;

        return $this;
    }

    public function getTypeCompte(): ?string
    {
        return $this->typeCompte;
    }

    public function setTypeCompte(string $typeCompte): self
    {
        $this->typeCompte = $typeCompte;

        return $this;
    }

    public function getStatusCompte(): ?string
    {
        return $this->statusCompte;
    }

    public function setStatusCompte(string $statusCompte): self
    {
        $this->statusCompte = $statusCompte;

        return $this;
    }

    /**
     * @return Collection|Accident[]
     */
    public function getAccidents(): Collection
    {
        return $this->accidents;
    }

    public function addAccident(Accident $accident): self
    {
        if (!$this->accidents->contains($accident)) {
            $this->accidents[] = $accident;
            $accident->setUser($this);
        }

        return $this;
    }

    public function removeAccident(Accident $accident): self
    {
        if ($this->accidents->removeElement($accident)) {
            // set the owning side to null (unless already changed)
            if ($accident->getUser() === $this) {
                $accident->setUser(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection|Incendie[]
     */
    public function getIncendies(): Collection
    {
        return $this->incendies;
    }

    public function addIncendy(Incendie $incendy): self
    {
        if (!$this->incendies->contains($incendy)) {
            $this->incendies[] = $incendy;
            $incendy->setUser($this);
        }

        return $this;
    }

    public function removeIncendy(Incendie $incendy): self
    {
        if ($this->incendies->removeElement($incendy)) {
            // set the owning side to null (unless already changed)
            if ($incendy->getUser() === $this) {
                $incendy->setUser(null);
            }
        }

        return $this;
    }
}
