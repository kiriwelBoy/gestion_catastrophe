<?php

namespace App\Entity\Accident;

use App\Repository\Accident\UsagerRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=UsagerRepository::class)
 */
class Usager
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $numeroMatricule;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $positionUsager;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $categorie;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $graviteBlessure;

    /**
     * @ORM\Column(type="string", length=10)
     */
    private $sexe;

    /**
     * @ORM\Column(type="string", length=4)
     */
    private $anneeNaiss;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $motifDeplacement;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $equipementSecu1;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $equipementSecu2;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $locPieton;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $actionPieton;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $etatPieton;

    /**
     * @ORM\ManyToOne(targetEntity=Accident::class, inversedBy="usagers")
     * @ORM\JoinColumn(nullable=false)
     */
    private $numAccident;


    

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getPositionUsager(): ?string
    {
        return $this->positionUsager;
    }

    public function setPositionUsager(string $positionUsager): self
    {
        $this->positionUsager = $positionUsager;

        return $this;
    }

    public function getCategorie(): ?string
    {
        return $this->categorie;
    }

    public function setCategorie(string $categorie): self
    {
        $this->categorie = $categorie;

        return $this;
    }

    public function getGraviteBlessure(): ?string
    {
        return $this->graviteBlessure;
    }

    public function setGraviteBlessure(string $graviteBlessure): self
    {
        $this->graviteBlessure = $graviteBlessure;

        return $this;
    }

    public function getSexe(): ?string
    {
        return $this->sexe;
    }

    public function setSexe(string $sexe): self
    {
        $this->sexe = $sexe;

        return $this;
    }

    public function getAnneeNaiss(): ?string
    {
        return $this->anneeNaiss;
    }

    public function setAnneeNaiss(string $anneeNaiss): self
    {
        $this->anneeNaiss = $anneeNaiss;

        return $this;
    }

    public function getMotifDeplacement(): ?string
    {
        return $this->motifDeplacement;
    }

    public function setMotifDeplacement(string $motifDeplacement): self
    {
        $this->motifDeplacement = $motifDeplacement;

        return $this;
    }

    public function getEquipementSecu1(): ?string
    {
        return $this->equipementSecu1;
    }

    public function setEquipementSecu1(string $equipementSecu1): self
    {
        $this->equipementSecu1 = $equipementSecu1;

        return $this;
    }

    public function getEquipementSecu2(): ?string
    {
        return $this->equipementSecu2;
    }

    public function setEquipementSecu2(string $equipementSecu2): self
    {
        $this->equipementSecu2 = $equipementSecu2;

        return $this;
    }

    public function getLocPieton(): ?string
    {
        return $this->locPieton;
    }

    public function setLocPieton(string $locPieton): self
    {
        $this->locPieton = $locPieton;

        return $this;
    }

    public function getActionPieton(): ?string
    {
        return $this->actionPieton;
    }

    public function setActionPieton(string $actionPieton): self
    {
        $this->actionPieton = $actionPieton;

        return $this;
    }

    public function getEtatPieton(): ?string
    {
        return $this->etatPieton;
    }

    public function setEtatPieton(string $etatPieton): self
    {
        $this->etatPieton = $etatPieton;

        return $this;
    }

    public function getNumAccident(): ?Accident
    {
        return $this->numAccident;
    }

    public function setNumAccident(?Accident $numAccident): self
    {
        $this->numAccident = $numAccident;

        return $this;
    }

    public function getNumeroMatricule(): ?string
    {
        return $this->numeroMatricule;
    }

    public function setNumeroMatricule(string $numeroMatricule): self
    {
        $this->numeroMatricule = $numeroMatricule;

        return $this;
    }

}
