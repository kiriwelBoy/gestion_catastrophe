<?php

namespace App\Entity\Accident;

use App\Repository\Accident\CaracteristiqueRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=CaracteristiqueRepository::class)
 */
class Caracteristique
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="date")
     */
    private $dateAccident;

    /**
     * @ORM\Column(type="time")
     */
    private $heure;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $departement;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $commune;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $lumiere;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $agglomeration;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $intersection;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $cdtionAtmospherique;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $collision;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $addresse;

    /**
     * @ORM\Column(type="float")
     */
    private $longitude;

    /**
     * @ORM\Column(type="float")
     */
    private $latitude;

    /**
     * @ORM\OneToOne(targetEntity=Accident::class, inversedBy="caracteristique", cascade={"persist", "remove"})
     */
    private $numAccident;

    

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDateAccident(): ?\DateTimeInterface
    {
        return $this->dateAccident;
    }

    public function setDateAccident(\DateTimeInterface $dateAccident): self
    {
        $this->dateAccident = $dateAccident;

        return $this;
    }

    public function getHeure(): ?\DateTimeInterface
    {
        return $this->heure;
    }

    public function setHeure(\DateTimeInterface $heure): self
    {
        $this->heure = $heure;

        return $this;
    }

    public function getDepartement(): ?string
    {
        return $this->departement;
    }

    public function setDepartement(string $departement): self
    {
        $this->departement = $departement;

        return $this;
    }

    public function getCommune(): ?string
    {
        return $this->commune;
    }

    public function setCommune(string $commune): self
    {
        $this->commune = $commune;

        return $this;
    }

    public function getLumiere(): ?string
    {
        return $this->lumiere;
    }

    public function setLumiere(string $lumiere): self
    {
        $this->lumiere = $lumiere;

        return $this;
    }

    public function getAgglomeration(): ?string
    {
        return $this->agglomeration;
    }

    public function setAgglomeration(string $agglomeration): self
    {
        $this->agglomeration = $agglomeration;

        return $this;
    }

    public function getIntersection(): ?string
    {
        return $this->intersection;
    }

    public function setIntersection(string $intersection): self
    {
        $this->intersection = $intersection;

        return $this;
    }

    public function getCdtionAtmospherique(): ?string
    {
        return $this->cdtionAtmospherique;
    }

    public function setCdtionAtmospherique(string $cdtionAtmospherique): self
    {
        $this->cdtionAtmospherique = $cdtionAtmospherique;

        return $this;
    }

    public function getCollision(): ?string
    {
        return $this->collision;
    }

    public function setCollision(string $collision): self
    {
        $this->collision = $collision;

        return $this;
    }

    public function getAddresse(): ?string
    {
        return $this->addresse;
    }

    public function setAddresse(string $addresse): self
    {
        $this->addresse = $addresse;

        return $this;
    }

    public function getLongitude(): ?string
    {
        return $this->longitude;
    }

    public function setLongitude(string $longitude): self
    {
        $this->longitude = $longitude;

        return $this;
    }

    public function getLatitude(): ?string
    {
        return $this->latitude;
    }

    public function setLatitude(string $latitude): self
    {
        $this->latitude = $latitude;

        return $this;
    }

    public function getNumAccident(): ?Accident
    {
        return $this->numAccident;
    }

    public function setNumAccident(?Accident $numAccident): self
    {
        $this->numAccident = $numAccident;

        return $this;
    }


}
