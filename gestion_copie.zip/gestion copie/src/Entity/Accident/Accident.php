<?php

namespace App\Entity\Accident;

use App\Entity\User\User;
use App\Repository\Accident\AccidentRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=AccidentRepository::class)
 */
class Accident
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;



    /**
     * @ORM\OneToMany(targetEntity=Vehicule::class, mappedBy="numAccident")
     */
    private $vehicules;

    /**
     * @ORM\OneToMany(targetEntity=Usager::class, mappedBy="numAccident")
     */
    private $usagers;

    /**
     * @ORM\OneToOne(targetEntity=Caracteristique::class, mappedBy="numAccident", cascade={"persist", "remove"})
     */
    private $caracteristique;

    /**
     * @ORM\ManyToOne(targetEntity=Lieu::class, cascade={"persist"}, inversedBy="numAccident")
     * @ORM\JoinColumn(nullable=false)
     */
    private $lieu;

    /**
     * @ORM\Column(type="string", length=10)
     */
    private $status;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $comment;

    /**
     * @ORM\ManyToOne(targetEntity=User::class, inversedBy="accidents")
     * @ORM\JoinColumn(nullable=false)
     */
    private $user;

    public function __construct()
    {
        $this->vehicules = new ArrayCollection();
        $this->usagers = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }



    /**
     * @return Collection|Vehicule[]
     */
    public function getVehicules(): Collection
    {
        return $this->vehicules;
    }

    public function addVehicule(Vehicule $vehicule): self
    {
        if (!$this->vehicules->contains($vehicule)) {
            $this->vehicules[] = $vehicule;
            $vehicule->setNumAccident($this);
        }

        return $this;
    }

    public function removeVehicule(Vehicule $vehicule): self
    {
        if ($this->vehicules->removeElement($vehicule)) {
            // set the owning side to null (unless already changed)
            if ($vehicule->getNumAccident() === $this) {
                $vehicule->setNumAccident(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection|Usager[]
     */
    public function getUsagers(): Collection
    {
        return $this->usagers;
    }

    public function addUsager(Usager $usager): self
    {
        if (!$this->usagers->contains($usager)) {
            $this->usagers[] = $usager;
            $usager->setNumAccident($this);
        }

        return $this;
    }

    public function removeUsager(Usager $usager): self
    {
        if ($this->usagers->removeElement($usager)) {
            // set the owning side to null (unless already changed)
            if ($usager->getNumAccident() === $this) {
                $usager->setNumAccident(null);
            }
        }

        return $this;
    }

    public function getCaracteristique(): ?Caracteristique
    {
        return $this->caracteristique;
    }

    public function setCaracteristique(?Caracteristique $caracteristique): self
    {
        // unset the owning side of the relation if necessary
        if ($caracteristique === null && $this->caracteristique !== null) {
            $this->caracteristique->setNumAccident(null);
        }

        // set the owning side of the relation if necessary
        if ($caracteristique !== null && $caracteristique->getNumAccident() !== $this) {
            $caracteristique->setNumAccident($this);
        }

        $this->caracteristique = $caracteristique;

        return $this;
    }

    public function getLieu(): ?Lieu
    {
        return $this->lieu;
    }

    public function setLieu(?Lieu $lieu): self
    {
        $this->lieu = $lieu;

        return $this;
    }

    public function getStatus(): ?string
    {
        return $this->status;
    }

    public function setStatus(string $status): self
    {
        $this->status = $status;

        return $this;
    }

    public function getComment(): ?string
    {
        return $this->comment;
    }

    public function setComment(string $comment): self
    {
        $this->comment = $comment;

        return $this;
    }

    public function getUser(): ?User
    {
        return $this->user;
    }

    public function setUser(?User $user): self
    {
        $this->user = $user;

        return $this;
    }
}
