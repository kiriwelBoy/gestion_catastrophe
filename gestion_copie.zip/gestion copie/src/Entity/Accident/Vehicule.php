<?php

namespace App\Entity\Accident;

use App\Repository\Accident\VehiculeRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=VehiculeRepository::class)
 */
class Vehicule
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

     /**
     * @ORM\Column(type="string", length=255)
     */
    private $numeroMatricule;
    
    /**
     * @ORM\Column(type="string", length=255)
     */
    private $sensCirculation;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $categVehicule;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $obstacleFixe;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $obstacleMobile;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $choc;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $manOeuvre;

    /**
     * @ORM\Column(type="integer")
     */
    private $nbreOccupant;

    /**
     * @ORM\ManyToOne(targetEntity=Accident::class, inversedBy="vehicules")
     * @ORM\JoinColumn(nullable=false)
     */
    private $numAccident;

   

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getSensCirculation(): ?string
    {
        return $this->sensCirculation;
    }

    public function setSensCirculation(string $sensCirculation): self
    {
        $this->sensCirculation = $sensCirculation;

        return $this;
    }

    public function getCategVehicule(): ?string
    {
        return $this->categVehicule;
    }

    public function setCategVehicule(string $categVehicule): self
    {
        $this->categVehicule = $categVehicule;

        return $this;
    }

    public function getObstacleFixe(): ?string
    {
        return $this->obstacleFixe;
    }

    public function setObstacleFixe(string $obstacleFixe): self
    {
        $this->obstacleFixe = $obstacleFixe;

        return $this;
    }

    public function getObstacleMobile(): ?string
    {
        return $this->obstacleMobile;
    }

    public function setObstacleMobile(string $obstacleMobile): self
    {
        $this->obstacleMobile = $obstacleMobile;

        return $this;
    }

    public function getChoc(): ?string
    {
        return $this->choc;
    }

    public function setChoc(string $choc): self
    {
        $this->choc = $choc;

        return $this;
    }

    public function getManOeuvre(): ?string
    {
        return $this->manOeuvre;
    }

    public function setManOeuvre(string $manOeuvre): self
    {
        $this->manOeuvre = $manOeuvre;

        return $this;
    }

    public function getNbreOccupant(): ?int
    {
        return $this->nbreOccupant;
    }

    public function setNbreOccupant(int $nbreOccupant): self
    {
        $this->nbreOccupant = $nbreOccupant;

        return $this;
    }

    public function getNumAccident(): ?Accident
    {
        return $this->numAccident;
    }

    public function setNumAccident(?Accident $numAccident): self
    {
        $this->numAccident = $numAccident;

        return $this;
    }

    public function getNumeroMatricule(): ?string
    {
        return $this->numeroMatricule;
    }

    public function setNumeroMatricule(string $numeroMatricule): self
    {
        $this->numeroMatricule = $numeroMatricule;

        return $this;
    }

}
