<?php

namespace App\Entity\Incendie;

use App\Repository\Incendie\InfoTempIntervRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=InfoTempIntervRepository::class)
 */
class InfoTempInterv
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="date")
     */
    private $datePremAlerte;

    /**
     * @ORM\Column(type="time")
     */
    private $heurePremAlerte;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $auteurAlerte;

    /**
     * @ORM\Column(type="date")
     */
    private $dateArrivPremInter;

    /**
     * @ORM\Column(type="time")
     */
    private $heureArrivPremInter;

    /**
     * @ORM\Column(type="date")
     */
    private $dateFinInter;

    /**
     * @ORM\Column(type="time")
     */
    private $heureFinInter;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $distance;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $distanceArret;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $surfaceFeuArriv;

    /**
     * @ORM\OneToOne(targetEntity=Incendie::class, inversedBy="infoTempInterv", cascade={"persist", "remove"})
     * @ORM\JoinColumn(nullable=false)
     */
    private $id_incendie;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDatePremAlerte(): ?\DateTimeInterface
    {
        return $this->datePremAlerte;
    }

    public function setDatePremAlerte(\DateTimeInterface $datePremAlerte): self
    {
        $this->datePremAlerte = $datePremAlerte;

        return $this;
    }

    public function getHeurePremAlerte(): ?\DateTimeInterface
    {
        return $this->heurePremAlerte;
    }

    public function setHeurePremAlerte(\DateTimeInterface $heurePremAlerte): self
    {
        $this->heurePremAlerte = $heurePremAlerte;

        return $this;
    }

    public function getAuteurAlerte(): ?string
    {
        return $this->auteurAlerte;
    }

    public function setAuteurAlerte(string $auteurAlerte): self
    {
        $this->auteurAlerte = $auteurAlerte;

        return $this;
    }

    public function getDateArrivPremInter(): ?\DateTimeInterface
    {
        return $this->dateArrivPremInter;
    }

    public function setDateArrivPremInter(\DateTimeInterface $dateArrivPremInter): self
    {
        $this->dateArrivPremInter = $dateArrivPremInter;

        return $this;
    }

    public function getHeureArrivPremInter(): ?\DateTimeInterface
    {
        return $this->heureArrivPremInter;
    }

    public function setHeureArrivPremInter(\DateTimeInterface $heureArrivPremInter): self
    {
        $this->heureArrivPremInter = $heureArrivPremInter;

        return $this;
    }

    public function getDateFinInter(): ?\DateTimeInterface
    {
        return $this->dateFinInter;
    }

    public function setDateFinInter(\DateTimeInterface $dateFinInter): self
    {
        $this->dateFinInter = $dateFinInter;

        return $this;
    }

    public function getHeureFinInter(): ?\DateTimeInterface
    {
        return $this->heureFinInter;
    }

    public function setHeureFinInter(\DateTimeInterface $heureFinInter): self
    {
        $this->heureFinInter = $heureFinInter;

        return $this;
    }

    public function getDistance(): ?string
    {
        return $this->distance;
    }

    public function setDistance(string $distance): self
    {
        $this->distance = $distance;

        return $this;
    }

    public function getDistanceArret(): ?string
    {
        return $this->distanceArret;
    }

    public function setDistanceArret(string $distanceArret): self
    {
        $this->distanceArret = $distanceArret;

        return $this;
    }

    public function getSurfaceFeuArriv(): ?string
    {
        return $this->surfaceFeuArriv;
    }

    public function setSurfaceFeuArriv(string $surfaceFeuArriv): self
    {
        $this->surfaceFeuArriv = $surfaceFeuArriv;

        return $this;
    }

    public function getIdIncendie(): ?Incendie
    {
        return $this->id_incendie;
    }

    public function setIdIncendie(Incendie $id_incendie): self
    {
        $this->id_incendie = $id_incendie;

        return $this;
    }
}
