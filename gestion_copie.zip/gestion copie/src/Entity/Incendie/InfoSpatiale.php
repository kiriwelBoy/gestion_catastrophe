<?php

namespace App\Entity\Incendie;

use App\Repository\Incendie\InfoSpatialeRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=InfoSpatialeRepository::class)
 */
class InfoSpatiale
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $surfaceParcourue;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $dommageCauses;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $causePresume;

    /**
     * @ORM\OneToOne(targetEntity=Incendie::class, inversedBy="infoSpatiale", cascade={"persist", "remove"})
     * @ORM\JoinColumn(nullable=false)
     */
    private $id_incendie;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getSurfaceParcourue(): ?string
    {
        return $this->surfaceParcourue;
    }

    public function setSurfaceParcourue(string $surfaceParcourue): self
    {
        $this->surfaceParcourue = $surfaceParcourue;

        return $this;
    }

    public function getDommageCauses(): ?string
    {
        return $this->dommageCauses;
    }

    public function setDommageCauses(string $dommageCauses): self
    {
        $this->dommageCauses = $dommageCauses;

        return $this;
    }

    public function getCausePresume(): ?string
    {
        return $this->causePresume;
    }

    public function setCausePresume(string $causePresume): self
    {
        $this->causePresume = $causePresume;

        return $this;
    }

    public function getIdIncendie(): ?Incendie
    {
        return $this->id_incendie;
    }

    public function setIdIncendie(Incendie $id_incendie): self
    {
        $this->id_incendie = $id_incendie;

        return $this;
    }
}
