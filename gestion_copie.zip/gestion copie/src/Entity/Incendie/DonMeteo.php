<?php

namespace App\Entity\Incendie;

use App\Repository\Incendie\DonMeteoRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=DonMeteoRepository::class)
 */
class DonMeteo
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $vitesseVent;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $temperatureLieu;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $humiditeAtmos;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $directionVent;

    /**
     * @ORM\OneToOne(targetEntity=Incendie::class, inversedBy="donMeteo", cascade={"persist", "remove"})
     * @ORM\JoinColumn(nullable=false)
     */
    private $id_incendie;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getVitesseVent(): ?string
    {
        return $this->vitesseVent;
    }

    public function setVitesseVent(string $vitesseVent): self
    {
        $this->vitesseVent = $vitesseVent;

        return $this;
    }

    public function getTemperatureLieu(): ?string
    {
        return $this->temperatureLieu;
    }

    public function setTemperatureLieu(string $temperatureLieu): self
    {
        $this->temperatureLieu = $temperatureLieu;

        return $this;
    }

    public function getHumiditeAtmos(): ?string
    {
        return $this->humiditeAtmos;
    }

    public function setHumiditeAtmos(string $humiditeAtmos): self
    {
        $this->humiditeAtmos = $humiditeAtmos;

        return $this;
    }

    public function getDirectionVent(): ?string
    {
        return $this->directionVent;
    }

    public function setDirectionVent(string $directionVent): self
    {
        $this->directionVent = $directionVent;

        return $this;
    }

    public function getIdIncendie(): ?Incendie
    {
        return $this->id_incendie;
    }

    public function setIdIncendie(Incendie $id_incendie): self
    {
        $this->id_incendie = $id_incendie;

        return $this;
    }
}
