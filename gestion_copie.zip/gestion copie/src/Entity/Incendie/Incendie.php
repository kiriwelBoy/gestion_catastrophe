<?php

namespace App\Entity\Incendie;

use App\Entity\User\User;
use App\Repository\Incendie\IncendieRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=IncendieRepository::class)
 */
class Incendie
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\OneToOne(targetEntity=CaracteristiqueIncendie::class, mappedBy="incendie", cascade={"persist", "remove"})
     */
    private $caracteristique;

    /**
     * @ORM\OneToOne(targetEntity=InfoTempInterv::class, mappedBy="id_incendie", cascade={"persist", "remove"})
     */
    private $infoTempInterv;

    /**
     * @ORM\OneToOne(targetEntity=InfoSpatiale::class, mappedBy="id_incendie", cascade={"persist", "remove"})
     */
    private $infoSpatiale;

    /**
     * @ORM\OneToOne(targetEntity=DonMeteo::class, mappedBy="id_incendie", cascade={"persist", "remove"})
     */
    private $donMeteo;

    /**
     * @ORM\Column(type="string", length=10)
     */
    private $status;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $comment;

    /**
     * @ORM\ManyToOne(targetEntity=User::class, inversedBy="incendies")
     * @ORM\JoinColumn(nullable=false)
     */
    private $user;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getCaracteristique(): ?CaracteristiqueIncendie
    {
        return $this->caracteristique;
    }

    public function setCaracteristique(CaracteristiqueIncendie $caracteristique): self
    {
        // set the owning side of the relation if necessary
        if ($caracteristique->getIncendie() !== $this) {
            $caracteristique->setIncendie($this);
        }

        $this->caracteristique = $caracteristique;

        return $this;
    }

    public function getInfoTempInterv(): ?InfoTempInterv
    {
        return $this->infoTempInterv;
    }

    public function setInfoTempInterv(InfoTempInterv $infoTempInterv): self
    {
        // set the owning side of the relation if necessary
        if ($infoTempInterv->getIdIncendie() !== $this) {
            $infoTempInterv->setIdIncendie($this);
        }

        $this->infoTempInterv = $infoTempInterv;

        return $this;
    }

    public function getInfoSpatiale(): ?InfoSpatiale
    {
        return $this->infoSpatiale;
    }

    public function setInfoSpatiale(InfoSpatiale $infoSpatiale): self
    {
        // set the owning side of the relation if necessary
        if ($infoSpatiale->getIdIncendie() !== $this) {
            $infoSpatiale->setIdIncendie($this);
        }

        $this->infoSpatiale = $infoSpatiale;

        return $this;
    }

    public function getDonMeteo(): ?DonMeteo
    {
        return $this->donMeteo;
    }

    public function setDonMeteo(DonMeteo $donMeteo): self
    {
        // set the owning side of the relation if necessary
        if ($donMeteo->getIdIncendie() !== $this) {
            $donMeteo->setIdIncendie($this);
        }

        $this->donMeteo = $donMeteo;

        return $this;
    }

    public function getUser(): ?User
    {
        return $this->user;
    }

    public function setUser(?User $user): self
    {
        $this->user = $user;

        return $this;
    }
}
