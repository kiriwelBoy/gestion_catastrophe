<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\Common\Persistence\ObjectManager;
use Doctrine\ORM\EntityManagerInterface;
use App\Entity\Accident\Caracteristique;
use App\Entity\Accident\Lieu;
use App\Entity\Accident\Accident;
use App\Entity\Accident\Vehicule;
use App\Entity\Accident\Usager;
use App\Entity\Incendie\CaracteristiqueIncendie;
use App\Entity\Incendie\InfoTempInterv;
use App\Entity\Incendie\InfoSpatiale;
use App\Entity\Incendie\DonMeteo;
use App\Entity\Incendie\Incendie;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use App\Form\Accident\CaracteristiqueType;
use App\Form\Accident\LieuType;
use App\Form\Accident\VehiculeType;
use App\Form\Accident\UsagerType;
use App\Form\Accident\AccidentType;

use App\Form\Incendie\DonMeteoType;
use App\Form\Incendie\IncendieType;
use App\Form\Incendie\InfoSpatialeType;
use App\Form\Incendie\InfoTempIntervType;







use Symfony\Component\Routing\Annotation\Route;

class GestionController extends AbstractController
{
    /**
     * @Route("/gestion", name="gestion")
     */
    public function index(): Response
    {
        return $this->render('gestion/index.html.twig', [
            'controller_name' => 'GestionController',
        ]);
    }

    /**
     * @Route("/", name="home")
     */
    public function home(): Response{
        return $this->render('gestion/home.html.twig');
    }

    /**
     * @Route("/accident/new", name="accident_create")
     */
    public function create(EntityManagerInterface $entityManager, Request $request){
        $accident = new Accident();

        $form = $this->createForm(AccidentType::class, $accident);

        $form ->handleRequest($request);

        if($form->isSubmitted() && $form->isValid()){
            foreach ($accident->getVehicules() as $vehicule) {
                $vehicule->setNumAccident($accident);
                $entityManager->persist($vehicule);
            }
            foreach ($accident->getUsagers() as $usager) {
                $usager->setNumAccident($accident);
                $entityManager->persist($usager);
            }
            foreach ($accident->getLieu() as $lieu) {
                $lieu->addNumAccident($accident);
                $entityManager->persist($lieu);
            }

            $accident = $form->getData();
            $entityManager->persist($accident);
            $entityManager->flush();

            $this->addFlash(
                'success',
                "Le formulaire a bien été envoyé"
            );
            return $this->redirectToRoute('home');
        }
              
        return $this->render('gestion/accident/create.html.twig',[
            'form'    => $form->createView()
        ]);

    }

    /**
     * @Route("/incendie/new", name="incendie_create")
     */
    public function createIncendieForm(Request $request, EntityManagerInterface $entityManager){
        $incedie = new Incendie();
                      
        $form = $this->createForm(IncendieType::class, $incedie);
        $form ->handleRequest($request);

        if($form->isSubmitted() && $form->isValid()){
            $incedie = $form->getData();
            $entityManager->persist($incedie);
            $entityManager->flush();
        }
        return $this->render('gestion/incendie/create.html.twig',[
            'form'             => $form->createView(),
        ]);
    }

    /**
     * @Route("/accident/{id}", name="show_accident")
     */
    public function showAccident(Accident $id): Response{
        return $this->render('accident/show.html.twig',[
            'accident' => $id
        ]);
    }

    /**
     * @Route("/compte_rendu", name="show_compte_rendu")
     */
   
    public function showCompteRendu(): Response
    {
        return $this->render('compteRendu/show.html.twig', []);
    }


}
