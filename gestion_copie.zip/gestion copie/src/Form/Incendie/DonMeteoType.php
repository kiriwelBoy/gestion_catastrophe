<?php

namespace App\Form\Incendie;

use App\Entity\Incendie\DonMeteo;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\TextType;

class DonMeteoType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('vitesseVent', TextType::class, [
                'label' => 'Vitesse du vent'
            ])
            ->add('temperatureLieu', TextType::class, [
                'label' => 'Temperature des lieux'
            ])
            ->add('humiditeAtmos', TextType::class, [
                'label' => 'Humidité de l\'atosphère'
            ])
            ->add('directionVent', TextType::class, [
                'label' => 'Direction du vent'
            ])
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => DonMeteo::class,
        ]);
    }
}
