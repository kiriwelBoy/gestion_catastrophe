<?php

namespace App\Form\Incendie;

use App\Entity\Incendie\Incendie;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use App\Form\Incendie\CaracteristiqueIncendieType;
use App\Form\Incendie\InfoTempIntervType;
use App\Form\Incendie\InfoSpatialeType;
use App\Form\Incendie\DonMeteoType;

use Symfony\Component\Form\Extension\Core\Type\SubmitType;


class IncendieType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('caracteristique', CaracteristiqueIncendieType::class, [
                'label' => 'CARACTÉRISTIQUE'
            ])
            ->add('infoTempInterv', InfoTempIntervType::class, [
                'label' => 'INFORMATIONS TEMPORELLES SUR L\'INTERVENTION '
            ])
            ->add('infoSpatiale', InfoSpatialeType::class, [
                'label' => 'INFORMATIONS SPATIALES'
            ])
            ->add('donMeteo', DonMeteoType::class, [
                'label' => 'DONNÉES MÉTÉOLOGIQUE'
            ])
            ->add('save', SubmitType::class, array('label'=> 'Envoyer'))
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Incendie::class,
        ]);
    }
}
