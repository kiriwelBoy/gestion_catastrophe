<?php

namespace App\Form\Incendie;

use App\Entity\Incendie\InfoTempInterv;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\TimeType;
use Symfony\Component\Form\Extension\Core\Type\TextType;


class InfoTempIntervType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('datePremAlerte', DateType::class, [
                'label' => 'Date de première alerte'
            ])
            ->add('heurePremAlerte', TimeType::class, [
                'label' => 'Heure de première alerte'
            ])                   
            ->add('auteurAlerte', ChoiceType::class, [
                'label' => 'Qui a lancé l\'alerte',
                'choices' => [
                    'population' => 'population',
                    'patrouille' => 'patrouille',
                    'gendarmerie' => 'gendarmerie',
                ]
            ])
            ->add('dateArrivPremInter', DateType::class, [
                'label' => 'Date d\'arrivée de la première intervention'
            ])
            ->add('heureArrivPremInter', TimeType::class, [
                'label' => 'Heure d\'arrivée de la première intervention'
            ])
            ->add('dateFinInter', DateType::class, [
                'label' => 'Date de fin de l\'intervention'
            ])
            ->add('heureFinInter', TimeType::class, [
                'label' => 'Heure de fin de l\'intervention'
            ])
            ->add('distance', TextType::class, [
                'label' => 'Distance pour arriver sur les lieux'
            ])
            ->add('distanceArret', TextType::class, [
                'label' => 'Distance d\'arret des engins/feu'
            ])
            ->add('surfaceFeuArriv', TextType::class, [
                'label' => 'Surface du feu à l\'arrivée des secours'
            ])
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => InfoTempInterv::class,
        ]);
    }
}
