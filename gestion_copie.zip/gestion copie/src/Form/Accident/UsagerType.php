<?php

namespace App\Form\Accident;

use App\Entity\Accident\Usager;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;

class UsagerType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('numeroMatricule')
            ->add('positionUsager')
            ->add('categorie')
            ->add('graviteBlessure')
            ->add('sexe')
            ->add('anneeNaiss')
            ->add('motifDeplacement')
            ->add('equipementSecu1')
            ->add('equipementSecu2')
            ->add('locPieton')
            ->add('actionPieton')
            ->add('etatPieton')
            //->add('save', SubmitType::class, array('label'=> 'Ajouter'))
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Usager::class,
        ]);
    }
}
