<?php

namespace App\Form\Accident;

use App\Entity\Accident\Accident;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use App\Form\Accident\CaracteristiqueType;
use App\Form\Accident\LieuType;
use App\Form\Accident\VehiculeType;
use App\Form\Accident\UsagerType;

class AccidentType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('caracteristique', CaracteristiqueType::class)
            ->add('lieu', LieuType::class)
            ->add('vehicules', CollectionType::class, [
                'entry_type' => VehiculeType::class,
                'entry_options' =>['label' => false],
                'allow_add'      => true,
                'allow_delete'  => true
            ])
            ->add('usagers', CollectionType::class, [
                'entry_type' => UsagerType::class,
                'entry_options' =>['label' => false],
                'allow_add'      => true,
                'allow_delete'  => true
            ])
            ->add('save', SubmitType::class, array('label' => 'Envoyer'))
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Accident::class,
        ]);
    }
}
