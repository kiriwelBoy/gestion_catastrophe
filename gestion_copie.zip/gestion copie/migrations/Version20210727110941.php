<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20210727110941 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE caracteristique_incendie (id INT AUTO_INCREMENT NOT NULL, incendie_id INT NOT NULL, latitude VARCHAR(255) NOT NULL, longitude VARCHAR(255) NOT NULL, heure_debut TIME NOT NULL, heure_fin TIME NOT NULL, type_feu VARCHAR(255) NOT NULL, date_debut DATE NOT NULL, date_fin DATE NOT NULL, region VARCHAR(255) NOT NULL, departement VARCHAR(255) NOT NULL, commune VARCHAR(255) NOT NULL, UNIQUE INDEX UNIQ_D1E0A5003BE34AF7 (incendie_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE don_meteo (id INT AUTO_INCREMENT NOT NULL, id_incendie_id INT NOT NULL, vitesse_vent VARCHAR(255) NOT NULL, temperature_lieu VARCHAR(255) NOT NULL, humidite_atmos VARCHAR(255) NOT NULL, direction_vent VARCHAR(255) NOT NULL, UNIQUE INDEX UNIQ_33396CE123F18700 (id_incendie_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE incendie (id INT AUTO_INCREMENT NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE info_spatiale (id INT AUTO_INCREMENT NOT NULL, id_incendie_id INT NOT NULL, surface_parcourue VARCHAR(255) NOT NULL, dommage_causes VARCHAR(255) NOT NULL, cause_presume VARCHAR(255) NOT NULL, UNIQUE INDEX UNIQ_88F1D04923F18700 (id_incendie_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE info_temp_interv (id INT AUTO_INCREMENT NOT NULL, id_incendie_id INT NOT NULL, date_prem_alerte DATE NOT NULL, heure_prem_alerte TIME NOT NULL, auteur_alerte VARCHAR(255) NOT NULL, date_arriv_prem_inter DATE NOT NULL, heure_arriv_prem_inter TIME NOT NULL, date_fin_inter DATE NOT NULL, heure_fin_inter TIME NOT NULL, distance VARCHAR(255) NOT NULL, distance_arret VARCHAR(255) NOT NULL, surface_feu_arriv VARCHAR(255) NOT NULL, UNIQUE INDEX UNIQ_1EBC7DA823F18700 (id_incendie_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE caracteristique_incendie ADD CONSTRAINT FK_D1E0A5003BE34AF7 FOREIGN KEY (incendie_id) REFERENCES incendie (id)');
        $this->addSql('ALTER TABLE don_meteo ADD CONSTRAINT FK_33396CE123F18700 FOREIGN KEY (id_incendie_id) REFERENCES incendie (id)');
        $this->addSql('ALTER TABLE info_spatiale ADD CONSTRAINT FK_88F1D04923F18700 FOREIGN KEY (id_incendie_id) REFERENCES incendie (id)');
        $this->addSql('ALTER TABLE info_temp_interv ADD CONSTRAINT FK_1EBC7DA823F18700 FOREIGN KEY (id_incendie_id) REFERENCES incendie (id)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE caracteristique_incendie DROP FOREIGN KEY FK_D1E0A5003BE34AF7');
        $this->addSql('ALTER TABLE don_meteo DROP FOREIGN KEY FK_33396CE123F18700');
        $this->addSql('ALTER TABLE info_spatiale DROP FOREIGN KEY FK_88F1D04923F18700');
        $this->addSql('ALTER TABLE info_temp_interv DROP FOREIGN KEY FK_1EBC7DA823F18700');
        $this->addSql('DROP TABLE caracteristique_incendie');
        $this->addSql('DROP TABLE don_meteo');
        $this->addSql('DROP TABLE incendie');
        $this->addSql('DROP TABLE info_spatiale');
        $this->addSql('DROP TABLE info_temp_interv');
    }
}
