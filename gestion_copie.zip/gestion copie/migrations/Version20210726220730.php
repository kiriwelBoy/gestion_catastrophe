<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20210726220730 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE usager DROP FOREIGN KEY FK_3CDC65FF913EBC2B');
        $this->addSql('DROP INDEX IDX_3CDC65FF913EBC2B ON usager');
        $this->addSql('ALTER TABLE usager ADD numero_matricule VARCHAR(255) NOT NULL, DROP numero_matricule_id');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE usager ADD numero_matricule_id INT NOT NULL, DROP numero_matricule');
        $this->addSql('ALTER TABLE usager ADD CONSTRAINT FK_3CDC65FF913EBC2B FOREIGN KEY (numero_matricule_id) REFERENCES vehicule (id) ON UPDATE NO ACTION ON DELETE NO ACTION');
        $this->addSql('CREATE INDEX IDX_3CDC65FF913EBC2B ON usager (numero_matricule_id)');
    }
}
