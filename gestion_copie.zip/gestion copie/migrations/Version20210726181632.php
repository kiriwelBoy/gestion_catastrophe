<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20210726181632 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE accident (id INT AUTO_INCREMENT NOT NULL, num_accident VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE caracteristique (id INT AUTO_INCREMENT NOT NULL, accidents_id INT NOT NULL, date_accident DATE NOT NULL, heure TIME NOT NULL, departement VARCHAR(255) NOT NULL, commune VARCHAR(255) NOT NULL, lumiere VARCHAR(255) NOT NULL, agglomeration VARCHAR(255) NOT NULL, intersection VARCHAR(255) NOT NULL, cdtion_atmospherique VARCHAR(255) NOT NULL, collision VARCHAR(255) NOT NULL, addresse VARCHAR(255) NOT NULL, longitude VARCHAR(255) NOT NULL, latitude VARCHAR(255) NOT NULL, UNIQUE INDEX UNIQ_D14FBE8B980D68CB (accidents_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE caracteristique ADD CONSTRAINT FK_D14FBE8B980D68CB FOREIGN KEY (accidents_id) REFERENCES accident (id)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE caracteristique DROP FOREIGN KEY FK_D14FBE8B980D68CB');
        $this->addSql('DROP TABLE accident');
        $this->addSql('DROP TABLE caracteristique');
    }
}
