<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20210726200332 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE lieu (id INT AUTO_INCREMENT NOT NULL, num_route VARCHAR(255) NOT NULL, regime_circ VARCHAR(255) NOT NULL, categprie_route VARCHAR(255) NOT NULL, nb_tot_voie INT NOT NULL, signale VARCHAR(255) NOT NULL, profile VARCHAR(255) NOT NULL, num_pr VARCHAR(255) NOT NULL, distance VARCHAR(255) NOT NULL, trace_plan VARCHAR(255) NOT NULL, largeur VARCHAR(255) NOT NULL, largeur1 VARCHAR(255) NOT NULL, etat_surface VARCHAR(255) NOT NULL, amenagement VARCHAR(255) NOT NULL, situation VARCHAR(255) NOT NULL, vmax INT NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE usager (id INT AUTO_INCREMENT NOT NULL, num_accident_id INT NOT NULL, numero_matricule_id INT NOT NULL, position_usager VARCHAR(255) NOT NULL, categorie VARCHAR(255) NOT NULL, gravite_blessure VARCHAR(255) NOT NULL, sexe VARCHAR(255) NOT NULL, annee_naiss VARCHAR(255) NOT NULL, motif_deplacement VARCHAR(255) NOT NULL, equipement_secu1 VARCHAR(255) NOT NULL, equipement_secu2 VARCHAR(255) NOT NULL, loc_pieton VARCHAR(255) NOT NULL, action_pieton VARCHAR(255) NOT NULL, etat_pieton VARCHAR(255) NOT NULL, INDEX IDX_3CDC65FF6C3D18A4 (num_accident_id), INDEX IDX_3CDC65FF913EBC2B (numero_matricule_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE vehicule (id INT AUTO_INCREMENT NOT NULL, num_accident_id INT NOT NULL, numero_matricule VARCHAR(255) NOT NULL, sens_circulation VARCHAR(255) NOT NULL, categ_vehicule VARCHAR(255) NOT NULL, obstacle_fixe VARCHAR(255) NOT NULL, obstacle_mobile VARCHAR(255) NOT NULL, choc VARCHAR(255) NOT NULL, man_oeuvre VARCHAR(255) NOT NULL, nbre_occupant INT NOT NULL, INDEX IDX_292FFF1D6C3D18A4 (num_accident_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE usager ADD CONSTRAINT FK_3CDC65FF6C3D18A4 FOREIGN KEY (num_accident_id) REFERENCES accident (id)');
        $this->addSql('ALTER TABLE usager ADD CONSTRAINT FK_3CDC65FF913EBC2B FOREIGN KEY (numero_matricule_id) REFERENCES vehicule (id)');
        $this->addSql('ALTER TABLE vehicule ADD CONSTRAINT FK_292FFF1D6C3D18A4 FOREIGN KEY (num_accident_id) REFERENCES accident (id)');
        $this->addSql('ALTER TABLE accident ADD lieu_id INT NOT NULL');
        $this->addSql('ALTER TABLE accident ADD CONSTRAINT FK_8F31DB6F6AB213CC FOREIGN KEY (lieu_id) REFERENCES lieu (id)');
        $this->addSql('CREATE INDEX IDX_8F31DB6F6AB213CC ON accident (lieu_id)');
        $this->addSql('ALTER TABLE caracteristique DROP FOREIGN KEY FK_D14FBE8B980D68CB');
        $this->addSql('DROP INDEX UNIQ_D14FBE8B980D68CB ON caracteristique');
        $this->addSql('ALTER TABLE caracteristique CHANGE accidents_id num_accident_id INT NOT NULL');
        $this->addSql('ALTER TABLE caracteristique ADD CONSTRAINT FK_D14FBE8B6C3D18A4 FOREIGN KEY (num_accident_id) REFERENCES accident (id)');
        $this->addSql('CREATE UNIQUE INDEX UNIQ_D14FBE8B6C3D18A4 ON caracteristique (num_accident_id)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE accident DROP FOREIGN KEY FK_8F31DB6F6AB213CC');
        $this->addSql('ALTER TABLE usager DROP FOREIGN KEY FK_3CDC65FF913EBC2B');
        $this->addSql('DROP TABLE lieu');
        $this->addSql('DROP TABLE usager');
        $this->addSql('DROP TABLE vehicule');
        $this->addSql('DROP INDEX IDX_8F31DB6F6AB213CC ON accident');
        $this->addSql('ALTER TABLE accident DROP lieu_id');
        $this->addSql('ALTER TABLE caracteristique DROP FOREIGN KEY FK_D14FBE8B6C3D18A4');
        $this->addSql('DROP INDEX UNIQ_D14FBE8B6C3D18A4 ON caracteristique');
        $this->addSql('ALTER TABLE caracteristique CHANGE num_accident_id accidents_id INT NOT NULL');
        $this->addSql('ALTER TABLE caracteristique ADD CONSTRAINT FK_D14FBE8B980D68CB FOREIGN KEY (accidents_id) REFERENCES accident (id) ON UPDATE NO ACTION ON DELETE NO ACTION');
        $this->addSql('CREATE UNIQUE INDEX UNIQ_D14FBE8B980D68CB ON caracteristique (accidents_id)');
    }
}
