<?php

namespace App\Entity;

use App\Repository\AccidentRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=AccidentRepository::class)
 */
class Accident
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\OneToOne(targetEntity=Caracteristiques::class, inversedBy="accident", cascade={"persist", "remove"})
     * @ORM\JoinColumn(nullable=false)
     */
    private $caracteristiques;

    /**
     * @ORM\OneToMany(targetEntity=Vehicule::class, mappedBy="accident")
     */
    private $Vehicule;

    /**
     * @ORM\ManyToOne(targetEntity=Lieu::class, inversedBy="accidentsregistre")
     * @ORM\JoinColumn(nullable=false)
     */
    private $Lieu;

    /**
     * @ORM\ManyToOne(targetEntity=Users::class, inversedBy="accidentsregis")
     * @ORM\JoinColumn(nullable=false)
     */
    private $User;

    /**
     * @ORM\OneToMany(targetEntity=Commentaires::class, mappedBy="accident")
     */
    private $Commentaires;

    /**
     * @ORM\OneToMany(targetEntity=Usager::class, mappedBy="accident")
     */
    private $Usager;

    public function __construct()
    {
        $this->Usager = new ArrayCollection();
        $this->Vehicule = new ArrayCollection();
        $this->Commentaires = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getCaracteristiques(): ?Caracteristiques
    {
        return $this->caracteristiques;
    }

    public function setCaracteristiques(Caracteristiques $caracteristiques): self
    {
        $this->caracteristiques = $caracteristiques;

        return $this;
    }


    /**
     * @return Collection|Vehicule[]
     */
    public function getVehicule(): Collection
    {
        return $this->Vehicule;
    }

    public function addVehicule(Vehicule $vehicule): self
    {
        if (!$this->Vehicule->contains($vehicule)) {
            $this->Vehicule[] = $vehicule;
            $vehicule->setAccident($this);
        }

        return $this;
    }

    public function removeVehicule(Vehicule $vehicule): self
    {
        if ($this->Vehicule->removeElement($vehicule)) {
            // set the owning side to null (unless already changed)
            if ($vehicule->getAccident() === $this) {
                $vehicule->setAccident(null);
            }
        }

        return $this;
    }

    public function getLieu(): ?Lieu
    {
        return $this->Lieu;
    }

    public function setLieu(?Lieu $Lieu): self
    {
        $this->Lieu = $Lieu;

        return $this;
    }

    public function getUser(): ?Users
    {
        return $this->User;
    }

    public function setUser(?Users $User): self
    {
        $this->User = $User;

        return $this;
    }

    /**
     * @return Collection|Commentaires[]
     */
    public function getCommentaires(): Collection
    {
        return $this->Commentaires;
    }

    public function addCommentaire(Commentaires $commentaire): self
    {
        if (!$this->Commentaires->contains($commentaire)) {
            $this->Commentaires[] = $commentaire;
            $commentaire->setAccident($this);
        }

        return $this;
    }

    public function removeCommentaire(Commentaires $commentaire): self
    {
        if ($this->Commentaires->removeElement($commentaire)) {
            // set the owning side to null (unless already changed)
            if ($commentaire->getAccident() === $this) {
                $commentaire->setAccident(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection|Usager[]
     */
    public function getUsager(): Collection
    {
        return $this->Usager;
    }

    public function addUsager(Usager $usager): self
    {
        if (!$this->Usager->contains($usager)) {
            $this->Usager[] = $usager;
            $usager->setAccident($this);
        }

        return $this;
    }

    public function removeUsager(Usager $usager): self
    {
        if ($this->Usager->removeElement($usager)) {
            // set the owning side to null (unless already changed)
            if ($usager->getAccident() === $this) {
                $usager->setAccident(null);
            }
        }

        return $this;
    }
}
