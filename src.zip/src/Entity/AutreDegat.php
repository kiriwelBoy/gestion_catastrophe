<?php

namespace App\Entity;

use App\Repository\AutreDegatRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=AutreDegatRepository::class)
 */
class AutreDegat
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $Poids_vi_det_emp;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    private $Nbre_anim_perdu;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $Type_anim_perdu;

    /**
     * @ORM\OneToOne(targetEntity=Innondations::class, mappedBy="autre_degat", cascade={"persist", "remove"})
     */
    private $Id_innondations;


    public function getId(): ?int
    {
        return $this->id;
    }

    public function getPoidsViDetEmp(): ?string
    {
        return $this->Poids_vi_det_emp;
    }

    public function setPoidsViDetEmp(?string $Poids_vi_det_emp): self
    {
        $this->Poids_vi_det_emp = $Poids_vi_det_emp;

        return $this;
    }

    public function getNbreAnimPerdu(): ?int
    {
        return $this->Nbre_anim_perdu;
    }

    public function setNbreAnimPerdu(?int $Nbre_anim_perdu): self
    {
        $this->Nbre_anim_perdu = $Nbre_anim_perdu;

        return $this;
    }

    public function getTypeAnimPerdu(): ?string
    {
        return $this->Type_anim_perdu;
    }

    public function setTypeAnimPerdu(?string $Type_anim_perdu): self
    {
        $this->Type_anim_perdu = $Type_anim_perdu;

        return $this;
    }

    public function getIdInnondations(): ?Innondations
    {
        return $this->Id_innondations;
    }

    public function setIdInnondations(?Innondations $Id_innondations): self
    {
        // unset the owning side of the  relation if necessary
        if ($Id_innondations === null && $this->Id_innondations !== null) {
            $this->Id_innondations->setAutreDegat(null);
        }

        // set the owning side of the relation if necessary
        if ($Id_innondations !== null && $Id_innondations->getAutreDegat() !== $this) {
            $Id_innondations->setAutreDegat($this);
        }

        $this->Id_innondations = $Id_innondations;

        return $this;
    }

}
