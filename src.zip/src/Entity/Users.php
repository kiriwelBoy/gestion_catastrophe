<?php

namespace App\Entity;

use App\Repository\UsersRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Security\Core\User\PasswordAuthenticatedUserInterface;
use Symfony\Component\Security\Core\User\UserInterface;

/**
 * @ORM\Entity(repositoryClass=UsersRepository::class)
 * @UniqueEntity(fields={"matricule"}, message="Veuillez changer d'identifiant car il existe déjà")
 */
class Users implements UserInterface, PasswordAuthenticatedUserInterface
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=180, unique=true)
     */
    private $matricule;

    /**
     * @ORM\Column(type="json")
     */
    private $roles = [];

     /**
     * @ORM\Column(type="string", length=255)
     */
    private $nom;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $prenom;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $adresse;

    /**
     * @ORM\Column(type="integer") 
     */
    private $Telephone;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $StatusCompte;
    
    /**
     * @var string The hashed password
     * @ORM\Column(type="string")
     */
    private $password;

    /**
     * @ORM\OneToMany(targetEntity=Accident::class, mappedBy="User")
     * @Assert\Regex(
     *     pattern="/^(?=.*[!?_@#$%^&*-])(?=.*[0-9])(?=.*[A-Z]).{8,20}$/",
     *     match=true,
     *     message="Veuillez saisir un mot de passe contenant au moins une lettre majuscule,un nombre (chiffre),un des caractères spéciaux suivants !@#$%^&*- , et composé au minimum de 8 caractères"
     * )
     */
    private $accidentsregis;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    private $idResp2;

    /**
     * @ORM\OneToMany(targetEntity=Incendie::class, mappedBy="user")
     */
    private $incendies;

    /**
     * @ORM\OneToMany(targetEntity=Innondations::class, mappedBy="user")
     */
    private $Id_innondations;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     * @Assert\Type( 
     *              type="alpha",
     *              message="Désolé, la valeur ne doit contenir que des lettres; veuillez saisir à nouveau."
     * )
     */
    private $Region;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $Departement;

    /**
     * @ORM\ManyToOne(targetEntity=Users::class, inversedBy="users")
     */
    private $idResp;

    /**
     * @ORM\OneToMany(targetEntity=Users::class, mappedBy="idResp")
     */
    private $users;



    public function __construct()
    {
        $this->accidentsregis = new ArrayCollection();
        $this->incendies = new ArrayCollection();
        $this->id_innondations = new ArrayCollection();
        $this->Id_innondations = new ArrayCollection();
        $this->users = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getMatricule(): ?string
    {
        return $this->matricule;
    }

    public function setMatricule(string $matricule): self
    {
        $this->matricule = $matricule;

        return $this;
    }

    /**
     * A visual identifier that represents this user.
     *
     * @see UserInterface
     */
    public function getUserIdentifier(): string
    {
        return (string) $this->matricule;
    }

    /**
     * @deprecated since Symfony 5.3, use getUserIdentifier instead
     */
    public function getUsername(): string
    {
        return (string) $this->matricule;
    }

    /**
     * @see UserInterface
     */
    public function getRoles(): array
    {
        $roles = $this->roles;
        // guarantee every user at least has ROLE_USER
        $roles[] = 'ROLE_USER';

        return array_unique($roles);
    }

    public function setRoles(array $roles): self
    {
        $this->roles = $roles;

        return $this;
    }

    /**
     * @see PasswordAuthenticatedUserInterface
     */
    public function getPassword(): string
    {
        return $this->password;
    }

    public function setPassword(string $password): self
    {
        $this->password = $password;

        return $this;
    }

    /**
     * Returning a salt is only needed, if you are not using a modern
     * hashing algorithm (e.g. bcrypt or sodium) in your security.yaml.
     *
     * @see UserInterface
     */
    public function getSalt(): ?string
    {
        return null;
    }

    /**
     * @see UserInterface
     */
    public function eraseCredentials()
    {
        // If you store any temporary, sensitive data on the user, clear it here
        // $this->plainPassword = null;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    public function getPrenom(): ?string
    {
        return $this->prenom;
    }

    public function setPrenom(string $prenom): self
    {
        $this->prenom = $prenom;

        return $this;
    }

    public function getAdresse(): ?string
    {
        return $this->adresse;
    }

    public function setAdresse(string $adresse): self
    {
        $this->adresse = $adresse;

        return $this;
    }

    public function getTelephone(): ?int
    {
        return $this->Telephone;
    }

    public function setTelephone(int $Telephone): self
    {
        $this->Telephone = $Telephone;

        return $this;
    }

    public function getStatusCompte(): ?string
    {
        return $this->StatusCompte;
    }

    public function setStatusCompte(string $StatusCompte): self
    {
        $this->StatusCompte = $StatusCompte;

        return $this;
    }

    /**
     * @return Collection|Accident[]
     */
    public function getAccidentsregis(): Collection
    {
        return $this->accidentsregis;
    }

    public function addAccidentsregi(Accident $accidentsregi): self
    {
        if (!$this->accidentsregis->contains($accidentsregi)) {
            $this->accidentsregis[] = $accidentsregi;
            $accidentsregi->setUser($this);
        }

        return $this;
    }

    public function removeAccidentsregi(Accident $accidentsregi): self
    {
        if ($this->accidentsregis->removeElement($accidentsregi)) {
            // set the owning side to null (unless already changed)
            if ($accidentsregi->getUser() === $this) {
                $accidentsregi->setUser(null);
            }
        }

        return $this;
    }


    /**
     * @return Collection|Incendie[]
     */
    public function getIncendies(): Collection
    {
        return $this->incendies;
    }

    public function addIncendy(Incendie $incendy): self
    {
        if (!$this->incendies->contains($incendy)) {
            $this->incendies[] = $incendy;
            $incendy->setUser($this);
        }

        return $this;
    }

    public function removeIncendy(Incendie $incendy): self
    {
        if ($this->incendies->removeElement($incendy)) {
            // set the owning side to null (unless already changed)
            if ($incendy->getUser() === $this) {
                $incendy->setUser(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection|Innondations[]
     */
    public function getIdInnondations(): Collection
    {
        return $this->Id_innondations;
    }

    public function addIdInnondation(Innondations $idInnondation): self
    {
        if (!$this->Id_innondations->contains($idInnondation)) {
            $this->Id_innondations[] = $idInnondation;
            $idInnondation->setUser($this);
        }

        return $this;
    }

    public function removeIdInnondation(Innondations $idInnondation): self
    {
        if ($this->Id_innondations->removeElement($idInnondation)) {
            // set the owning side to null (unless already changed)
            if ($idInnondation->getUser() === $this) {
                $idInnondation->setUser(null);
            }
        }

        return $this;
    }

    public function getRegion(): ?string
    {
        return $this->Region;
    }

    public function setRegion(?string $Region): self
    {
        $this->Region = $Region;

        return $this;
    }

    public function getDepartement(): ?string
    {
        return $this->Departement;
    }

    public function setDepartement(?string $Departement): self
    {
        $this->Departement = $Departement;

        return $this;
    }

    /**
     * @return Collection|self[]
     */
    public function getUsers(): Collection
    {
        return $this->users;
    }

    public function addUser(self $user): self
    {
        if (!$this->users->contains($user)) {
            $this->users[] = $user;
            $user->setIdResp($this);
        }

        return $this;
    }

    public function removeUser(self $user): self
    {
        if ($this->users->removeElement($user)) {
            // set the owning side to null (unless already changed)
            if ($user->getIdResp() === $this) {
                $user->setIdResp(null);
            }
        }

        return $this;
    }

    public function getIdResp2(): ?int
    {
        return $this->idResp2;
    }

    public function setIdResp2(?int $idResp2): self
    {
        $this->idResp2 = $idResp2;

        return $this;
    }

    public function getIdResp(): ?self
    {
        return $this->idResp;
    }

    public function setIdResp(?self $idResp): self
    {
        $this->idResp = $idResp;

        return $this;
    }



}
