<?php

namespace App\Entity;

use App\Repository\CaracteristiquesInnondationsRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=CaracteristiquesInnondationsRepository::class)
 */
class CaracteristiquesInnondations
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="float")
     */
    private $Volumetrie;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Type_Innon;

    /**
     * @ORM\Column(type="datetime")
     */
    private $Date;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Cause;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Region;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Departement;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Commune;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $Ville;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $Village;

    /**
     * @ORM\OneToOne(targetEntity=Innondations::class, mappedBy="caracteristiques", cascade={"persist", "remove"})
     */
    private $id_innondations;


    public function getId(): ?int
    {
        return $this->id;
    }

    public function getVolumetrie(): ?float
    {
        return $this->Volumetrie;
    }

    public function setVolumetrie(float $Volumetrie): self
    {
        $this->Volumetrie = $Volumetrie;

        return $this;
    }

    public function getTypeInnon(): ?string
    {
        return $this->Type_Innon;
    }

    public function setTypeInnon(string $Type_Innon): self
    {
        $this->Type_Innon = $Type_Innon;

        return $this;
    }

    public function getDate(): ?\DateTimeInterface
    {
        return $this->Date;
    }

    public function setDate(\DateTimeInterface $Date): self
    {
        $this->Date = $Date;

        return $this;
    }

    public function getCause(): ?string
    {
        return $this->Cause;
    }

    public function setCause(string $Cause): self
    {
        $this->Cause = $Cause;

        return $this;
    }

    public function getRegion(): ?string
    {
        return $this->Region;
    }

    public function setRegion(string $Region): self
    {
        $this->Region = $Region;

        return $this;
    }

    public function getDepartement(): ?string
    {
        return $this->Departement;
    }

    public function setDepartement(string $Departement): self
    {
        $this->Departement = $Departement;

        return $this;
    }

    public function getCommune(): ?string
    {
        return $this->Commune;
    }

    public function setCommune(string $Commune): self
    {
        $this->Commune = $Commune;

        return $this;
    }

    public function getVille(): ?string
    {
        return $this->Ville;
    }

    public function setVille(?string $Ville): self
    {
        $this->Ville = $Ville;

        return $this;
    }

    public function getVillage(): ?string
    {
        return $this->Village;
    }

    public function setVillage(?string $Village): self
    {
        $this->Village = $Village;

        return $this;
    }

    public function getIdInnondations(): ?Innondations
    {
        return $this->id_innondations;
    }

    public function setIdInnondations(Innondations $id_innondations): self
    {
        // set the owning side of the relation if necessary
        if ($id_innondations->getCaracteristiques() !== $this) {
            $id_innondations->setCaracteristiques($this);
        }

        $this->id_innondations = $id_innondations;

        return $this;
    }


}
