<?php

namespace App\Entity;

use App\Repository\CommentairesRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=CommentairesRepository::class)
 */
class Commentaires
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="text")
     */
    private $Contenu;

    /**
     * @ORM\Column(type="boolean")
     */
    private $actif = false;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $matricule;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $email;

    /**
     * @ORM\Column(type="boolean")
     */
    private $rgpd = false;

    /**
     * @ORM\Column(type="datetime")
     */
    private $created_at;

    /**
     * @ORM\ManyToOne(targetEntity=Accidents::class, inversedBy="Commentaires")
     */
    private $accidents;

    /**
     * @ORM\ManyToOne(targetEntity=Accident::class, inversedBy="Commentaires")
     * @ORM\JoinColumn(nullable=false)
     */
    private $accident;

    /**
     * @ORM\ManyToOne(targetEntity=Incendie::class, inversedBy="commentaires")
     */
    private $incendie;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getContenu(): ?string
    {
        return $this->Contenu;
    }

    public function setContenu(string $Contenu): self
    {
        $this->Contenu = $Contenu;

        return $this;
    }

    public function getActif(): ?bool
    {
        return $this->actif;
    }

    public function setActif(bool $actif): self
    {
        $this->actif = $actif;

        return $this;
    }

    public function getMatricule(): ?string
    {
        return $this->matricule;
    }

    public function setMatricule(string $matricule): self
    {
        $this->matricule = $matricule;

        return $this;
    }

    public function getEmail(): ?string
    {
        return $this->email;
    }

    public function setEmail(string $email): self
    {
        $this->email = $email;

        return $this;
    }

    public function getRgpd(): ?bool
    {
        return $this->rgpd;
    }

    public function setRgpd(bool $rgpd): self
    {
        $this->rgpd = $rgpd;

        return $this;
    }

    public function getCreatedAt(): ?\DateTimeInterface
    {
        return $this->created_at;
    }

    public function setCreatedAt(\DateTimeInterface $created_at): self
    {
        $this->created_at = $created_at;

        return $this;
    }

    public function getAccidents(): ?Accidents
    {
        return $this->accidents;
    }

    public function setAccidents(?Accidents $accidents): self
    {
        $this->accidents = $accidents;

        return $this;
    }

    public function getAccident(): ?Accident
    {
        return $this->accident;
    }

    public function setAccident(?Accident $accident): self
    {
        $this->accident = $accident;

        return $this;
    }

    public function getIncendie(): ?Incendie
    {
        return $this->incendie;
    }

    public function setIncendie(?Incendie $incendie): self
    {
        $this->incendie = $incendie;

        return $this;
    }
}
