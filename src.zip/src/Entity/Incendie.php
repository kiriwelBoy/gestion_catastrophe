<?php

namespace App\Entity;

use App\Repository\IncendieRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=IncendieRepository::class)
 */
class Incendie
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\OneToOne(targetEntity=CaracteristiquesIncendies::class, inversedBy="incendie_id", cascade={"persist", "remove"})
     * @ORM\JoinColumn(nullable=false)
     */
    private $caracteristique;

    /**
     * @ORM\OneToOne(targetEntity=DonMeteo::class, inversedBy="id_incendie", cascade={"persist", "remove"})
     * @ORM\JoinColumn(nullable=false)
     */
    private $donneeMeteo;

    /**
     * @ORM\OneToOne(targetEntity=InfoSpatiale::class, inversedBy="Id_Incendie", cascade={"persist", "remove"})
     * @ORM\JoinColumn(nullable=false)
     */
    private $Infospatiale;

    /**
     * @ORM\OneToOne(targetEntity=InfoTempInterv::class, inversedBy="Id_incendie", cascade={"persist", "remove"})
     * @ORM\JoinColumn(nullable=false)
     */
    private $info_temp_interv;

    /**
     * @ORM\ManyToOne(targetEntity=Users::class, inversedBy="incendies")
     * @ORM\JoinColumn(nullable=false)
     */
    private $user;

    /**
     * @ORM\OneToMany(targetEntity=Commentaires::class, mappedBy="incendie")
     */
    private $commentaires;

    public function __construct()
    {
        $this->commentaires = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getCaracteristique(): ?CaracteristiquesIncendies
    {
        return $this->caracteristique;
    }

    public function setCaracteristique(CaracteristiquesIncendies $caracteristique): self
    {
        $this->caracteristique = $caracteristique;

        return $this;
    }

    public function getDonneeMeteo(): ?DonMeteo
    {
        return $this->donneeMeteo;
    }

    public function setDonneeMeteo(DonMeteo $donneeMeteo): self
    {
        $this->donneeMeteo = $donneeMeteo;

        return $this;
    }

    public function getInfospatiale(): ?InfoSpatiale
    {
        return $this->Infospatiale;
    }

    public function setInfospatiale(InfoSpatiale $Infospatiale): self
    {
        $this->Infospatiale = $Infospatiale;

        return $this;
    }

    public function getInfoTempInterv(): ?InfoTempInterv
    {
        return $this->info_temp_interv;
    }

    public function setInfoTempInterv(InfoTempInterv $info_temp_interv): self
    {
        $this->info_temp_interv = $info_temp_interv;

        return $this;
    }

    public function getUser(): ?Users
    {
        return $this->user;
    }

    public function setUser(?Users $user): self
    {
        $this->user = $user;

        return $this;
    }

    /**
     * @return Collection|Commentaires[]
     */
    public function getCommentaires(): Collection
    {
        return $this->commentaires;
    }

    public function addCommentaire(Commentaires $commentaire): self
    {
        if (!$this->commentaires->contains($commentaire)) {
            $this->commentaires[] = $commentaire;
            $commentaire->setIncendie($this);
        }

        return $this;
    }

    public function removeCommentaire(Commentaires $commentaire): self
    {
        if ($this->commentaires->removeElement($commentaire)) {
            // set the owning side to null (unless already changed)
            if ($commentaire->getIncendie() === $this) {
                $commentaire->setIncendie(null);
            }
        }

        return $this;
    }
}
