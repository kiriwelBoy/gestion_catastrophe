<?php

namespace App\Entity;

use App\Repository\CompteRenduRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=CompteRenduRepository::class)
 */
class CompteRendu
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $TypeCompteRendu;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Statut;

    /**
     * @ORM\Column(type="text", nullable=true)
     */
    private $Commentaires;

    /**
     * @ORM\ManyToOne(targetEntity=CompteAdmin::class, inversedBy="CompteRendu")
     * @ORM\JoinColumn(nullable=false)
     */
    private $compteAdmin;

    /**
     * @ORM\ManyToOne(targetEntity=CompteModerateur::class, inversedBy="CompteRendu")
     * @ORM\JoinColumn(nullable=false)
     */
    private $compteModerateur;

    /**
     * @ORM\ManyToOne(targetEntity=CompteAgent::class, inversedBy="CompteRendu")
     * @ORM\JoinColumn(nullable=false)
     */
    private $compteAgent;

    /**
     * @ORM\OneToMany(targetEntity=Notifications::class, mappedBy="CompteRendu")
     */
    private $notifications;

    public function __construct()
    {
        $this->notifications = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getTypeCompteRendu(): ?string
    {
        return $this->TypeCompteRendu;
    }

    public function setTypeCompteRendu(string $TypeCompteRendu): self
    {
        $this->TypeCompteRendu = $TypeCompteRendu;

        return $this;
    }

    public function getStatut(): ?string
    {
        return $this->Statut;
    }

    public function setStatut(string $Statut): self
    {
        $this->Statut = $Statut;

        return $this;
    }

    public function getCommentaires(): ?string
    {
        return $this->Commentaires;
    }

    public function setCommentaires(?string $Commentaires): self
    {
        $this->Commentaires = $Commentaires;

        return $this;
    }

    public function getCompteAdmin(): ?CompteAdmin
    {
        return $this->compteAdmin;
    }

    public function setCompteAdmin(?CompteAdmin $compteAdmin): self
    {
        $this->compteAdmin = $compteAdmin;

        return $this;
    }

    public function getCompteModerateur(): ?CompteModerateur
    {
        return $this->compteModerateur;
    }

    public function setCompteModerateur(?CompteModerateur $compteModerateur): self
    {
        $this->compteModerateur = $compteModerateur;

        return $this;
    }

    public function getCompteAgent(): ?CompteAgent
    {
        return $this->compteAgent;
    }

    public function setCompteAgent(?CompteAgent $compteAgent): self
    {
        $this->compteAgent = $compteAgent;

        return $this;
    }

    /**
     * @return Collection|Notifications[]
     */
    public function getNotifications(): Collection
    {
        return $this->notifications;
    }

    public function addNotification(Notifications $notification): self
    {
        if (!$this->notifications->contains($notification)) {
            $this->notifications[] = $notification;
            $notification->setCompteRendu($this);
        }

        return $this;
    }

    public function removeNotification(Notifications $notification): self
    {
        if ($this->notifications->removeElement($notification)) {
            // set the owning side to null (unless already changed)
            if ($notification->getCompteRendu() === $this) {
                $notification->setCompteRendu(null);
            }
        }

        return $this;
    }
}
