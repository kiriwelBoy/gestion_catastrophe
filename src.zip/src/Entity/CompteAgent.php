<?php

namespace App\Entity;

use App\Repository\CompteAgentRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=CompteAgentRepository::class)
 */
class CompteAgent
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\OneToMany(targetEntity=CompteRendu::class, mappedBy="compteAgent")
     */
    private $CompteRendu;

    /**
     * @ORM\ManyToOne(targetEntity=CompteModerateur::class, inversedBy="compteAgents")
     * @ORM\JoinColumn(nullable=false)
     */
    private $CompteModerateur;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Matricule;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Nom;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Prenom;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Adresse;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Email;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $MotDePasse;

    /**
     * @ORM\Column(type="integer")
     */
    private $Telephone;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $StatusCompte;

    public function __construct()
    {
        $this->CompteRendu = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * @return Collection|CompteRendu[]
     */
    public function getCompteRendu(): Collection
    {
        return $this->CompteRendu;
    }

    public function addCompteRendu(CompteRendu $compteRendu): self
    {
        if (!$this->CompteRendu->contains($compteRendu)) {
            $this->CompteRendu[] = $compteRendu;
            $compteRendu->setCompteAgent($this);
        }

        return $this;
    }

    public function removeCompteRendu(CompteRendu $compteRendu): self
    {
        if ($this->CompteRendu->removeElement($compteRendu)) {
            // set the owning side to null (unless already changed)
            if ($compteRendu->getCompteAgent() === $this) {
                $compteRendu->setCompteAgent(null);
            }
        }

        return $this;
    }

    public function getCompteModerateur(): ?CompteModerateur
    {
        return $this->CompteModerateur;
    }

    public function setCompteModerateur(?CompteModerateur $CompteModerateur): self
    {
        $this->CompteModerateur = $CompteModerateur;

        return $this;
    }

    public function getMatricule(): ?string
    {
        return $this->Matricule;
    }

    public function setMatricule(string $Matricule): self
    {
        $this->Matricule = $Matricule;

        return $this;
    }

    public function getNom(): ?string
    {
        return $this->Nom;
    }

    public function setNom(string $Nom): self
    {
        $this->Nom = $Nom;

        return $this;
    }

    public function getPrenom(): ?string
    {
        return $this->Prenom;
    }

    public function setPrenom(string $Prenom): self
    {
        $this->Prenom = $Prenom;

        return $this;
    }

    public function getAdresse(): ?string
    {
        return $this->Adresse;
    }

    public function setAdresse(string $Adresse): self
    {
        $this->Adresse = $Adresse;

        return $this;
    }

    public function getEmail(): ?string
    {
        return $this->Email;
    }

    public function setEmail(string $Email): self
    {
        $this->Email = $Email;

        return $this;
    }

    public function getMotDePasse(): ?string
    {
        return $this->MotDePasse;
    }

    public function setMotDePasse(string $MotDePasse): self
    {
        $this->MotDePasse = $MotDePasse;

        return $this;
    }

    public function getTelephone(): ?int
    {
        return $this->Telephone;
    }

    public function setTelephone(int $Telephone): self
    {
        $this->Telephone = $Telephone;

        return $this;
    }

    public function getStatusCompte(): ?string
    {
        return $this->StatusCompte;
    }

    public function setStatusCompte(string $StatusCompte): self
    {
        $this->StatusCompte = $StatusCompte;

        return $this;
    }
}
