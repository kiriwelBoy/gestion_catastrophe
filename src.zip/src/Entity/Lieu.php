<?php

namespace App\Entity;

use App\Repository\LieuRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=LieuRepository::class)
 */
class Lieu
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $num_route;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $regime_circ;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $categprie_route;

    /**
     * @ORM\Column(type="integer")
     */
    private $nbTotVoie;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $signale;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $profile;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $numPR;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $distance;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $tracePlan;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $largeur;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $largeur1;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $etatSurface;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $amenagement;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $situation;

    /**
     * @ORM\Column(type="integer")
     */
    private $vmax;


    /**
     * @ORM\OneToMany(targetEntity=Accident::class, mappedBy="Lieu")
     */
    private $accidentsregistre;

 



    public function __construct()
    {
        $this->accidents = new ArrayCollection();
        $this->accidentsregistre = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }


    /**
     * @return Collection|Accident[]
     */
    public function getAccidentsregistre(): Collection
    {
        return $this->accidentsregistre;
    }

    public function addAccidentsregistre(Accident $accidentsregistre): self
    {
        if (!$this->accidentsregistre->contains($accidentsregistre)) {
            $this->accidentsregistre[] = $accidentsregistre;
            $accidentsregistre->setLieu($this);
        }

        return $this;
    }

    public function removeAccidentsregistre(Accident $accidentsregistre): self
    {
        if ($this->accidentsregistre->removeElement($accidentsregistre)) {
            // set the owning side to null (unless already changed)
            if ($accidentsregistre->getLieu() === $this) {
                $accidentsregistre->setLieu(null);
            }
        }

        return $this;
    }

    public function getNumRoute(): ?string
    {
        return $this->num_route;
    }

    public function setNumRoute(string $num_route): self
    {
        $this->num_route = $num_route;

        return $this;
    }

    public function getRegimeCirc(): ?string
    {
        return $this->regime_circ;
    }

    public function setRegimeCirc(string $regime_circ): self
    {
        $this->regime_circ = $regime_circ;

        return $this;
    }

    public function getCategprieRoute(): ?string
    {
        return $this->categprie_route;
    }

    public function setCategprieRoute(string $categprie_route): self
    {
        $this->categprie_route = $categprie_route;

        return $this;
    }

    public function getNbTotVoie(): ?int
    {
        return $this->nbTotVoie;
    }

    public function setNbTotVoie(int $nbTotVoie): self
    {
        $this->nbTotVoie = $nbTotVoie;

        return $this;
    }

    public function getSignale(): ?string
    {
        return $this->signale;
    }

    public function setSignale(string $signale): self
    {
        $this->signale = $signale;

        return $this;
    }

    public function getProfile(): ?string
    {
        return $this->profile;
    }

    public function setProfile(string $profile): self
    {
        $this->profile = $profile;

        return $this;
    }

    public function getNumPR(): ?string
    {
        return $this->numPR;
    }

    public function setNumPR(string $numPR): self
    {
        $this->numPR = $numPR;

        return $this;
    }

    public function getDistance(): ?string
    {
        return $this->distance;
    }

    public function setDistance(string $distance): self
    {
        $this->distance = $distance;

        return $this;
    }

    public function getTracePlan(): ?string
    {
        return $this->tracePlan;
    }

    public function setTracePlan(string $tracePlan): self
    {
        $this->tracePlan = $tracePlan;

        return $this;
    }

    public function getLargeur(): ?string
    {
        return $this->largeur;
    }

    public function setLargeur(string $largeur): self
    {
        $this->largeur = $largeur;

        return $this;
    }

    public function getLargeur1(): ?string
    {
        return $this->largeur1;
    }

    public function setLargeur1(string $largeur1): self
    {
        $this->largeur1 = $largeur1;

        return $this;
    }

    public function getEtatSurface(): ?string
    {
        return $this->etatSurface;
    }

    public function setEtatSurface(string $etatSurface): self
    {
        $this->etatSurface = $etatSurface;

        return $this;
    }

    public function getAmenagement(): ?string
    {
        return $this->amenagement;
    }

    public function setAmenagement(string $amenagement): self
    {
        $this->amenagement = $amenagement;

        return $this;
    }

    public function getSituation(): ?string
    {
        return $this->situation;
    }

    public function setSituation(string $situation): self
    {
        $this->situation = $situation;

        return $this;
    }

    public function getVmax(): ?int
    {
        return $this->vmax;
    }

    public function setVmax(int $vmax): self
    {
        $this->vmax = $vmax;

        return $this;
    }

}
