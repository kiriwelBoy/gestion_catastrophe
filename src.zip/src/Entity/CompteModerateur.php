<?php

namespace App\Entity;

use App\Repository\CompteModerateurRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=CompteModerateurRepository::class)
 */
class CompteModerateur
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\OneToMany(targetEntity=CompteRendu::class, mappedBy="compteModerateur")
     */
    private $CompteRendu;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Matricule;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Nom;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Prenom;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Adresse;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Email;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $MotDePasse;

    /**
     * @ORM\Column(type="integer")
     */
    private $Telephone;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $StatusCompte;

    /**
     * @ORM\ManyToOne(targetEntity=CompteAdmin::class, inversedBy="compteModerateurs")
     * @ORM\JoinColumn(nullable=false)
     */
    private $CompteAdmin;

    /**
     * @ORM\OneToMany(targetEntity=CompteAgent::class, mappedBy="CompteModerateur")
     */
    private $compteAgents;

    public function __construct()
    {
        $this->CompteRendu = new ArrayCollection();
        $this->compteAgents = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * @return Collection|CompteRendu[]
     */
    public function getCompteRendu(): Collection
    {
        return $this->CompteRendu;
    }

    public function addCompteRendu(CompteRendu $compteRendu): self
    {
        if (!$this->CompteRendu->contains($compteRendu)) {
            $this->CompteRendu[] = $compteRendu;
            $compteRendu->setCompteModerateur($this);
        }

        return $this;
    }

    public function removeCompteRendu(CompteRendu $compteRendu): self
    {
        if ($this->CompteRendu->removeElement($compteRendu)) {
            // set the owning side to null (unless already changed)
            if ($compteRendu->getCompteModerateur() === $this) {
                $compteRendu->setCompteModerateur(null);
            }
        }

        return $this;
    }

    public function getMatricule(): ?string
    {
        return $this->Matricule;
    }

    public function setMatricule(string $Matricule): self
    {
        $this->Matricule = $Matricule;

        return $this;
    }

    public function getNom(): ?string
    {
        return $this->Nom;
    }

    public function setNom(string $Nom): self
    {
        $this->Nom = $Nom;

        return $this;
    }


    public function getAdresse(): ?string
    {
        return $this->Adresse;
    }

    public function setAdresse(string $Adresse): self
    {
        $this->Adresse = $Adresse;

        return $this;
    }

    public function getEmail(): ?string
    {
        return $this->Email;
    }

    public function setEmail(string $Email): self
    {
        $this->Email = $Email;

        return $this;
    }

    public function getMotDePasse(): ?string
    {
        return $this->MotDePasse;
    }

    public function setMotDePasse(string $MotDePasse): self
    {
        $this->MotDePasse = $MotDePasse;

        return $this;
    }


    public function getStatusCompte(): ?string
    {
        return $this->StatusCompte;
    }

    public function setStatusCompte(string $StatusCompte): self
    {
        $this->StatusCompte = $StatusCompte;

        return $this;
    }

    public function getCompteAdmin(): ?CompteAdmin
    {
        return $this->CompteAdmin;
    }

    public function setCompteAdmin(?CompteAdmin $CompteAdmin): self
    {
        $this->CompteAdmin = $CompteAdmin;

        return $this;
    }

    /**
     * @return Collection|CompteAgent[]
     */
    public function getCompteAgents(): Collection
    {
        return $this->compteAgents;
    }

    public function addCompteAgent(CompteAgent $compteAgent): self
    {
        if (!$this->compteAgents->contains($compteAgent)) {
            $this->compteAgents[] = $compteAgent;
            $compteAgent->setCompteModerateur($this);
        }

        return $this;
    }

    public function removeCompteAgent(CompteAgent $compteAgent): self
    {
        if ($this->compteAgents->removeElement($compteAgent)) {
            // set the owning side to null (unless already changed)
            if ($compteAgent->getCompteModerateur() === $this) {
                $compteAgent->setCompteModerateur(null);
            }
        }

        return $this;
    }

    public function getPrenom(): ?string
    {
        return $this->Prenom;
    }

    public function setPrenom(string $Prenom): self
    {
        $this->Prenom = $Prenom;

        return $this;
    }

    public function getTelephone(): ?int
    {
        return $this->Telephone;
    }

    public function setTelephone(int $Telephone): self
    {
        $this->Telephone = $Telephone;

        return $this;
    }
}
