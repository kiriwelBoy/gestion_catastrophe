<?php

namespace App\Entity;

use App\Repository\AccidentsRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=AccidentsRepository::class)
 */
class Accidents
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="datetime")
     */
    private $Date;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    private $Nbre_Tuees;

    /**
     * @ORM\Column(type="integer")
     */
    private $Nbre_Usagers;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    private $Nbre_Blesses;

    /**
     * @ORM\Column(type="integer")
     */
    private $Nbre_Vi;

    /**
     * @ORM\OneToOne(targetEntity=Caracteristiques::class, inversedBy="accidents", cascade={"persist", "remove"})
     * @ORM\JoinColumn(nullable=false)
     */
    private $carateristiques;

    /**
     * @ORM\OneToMany(targetEntity=Usager::class, mappedBy="accidents")
     */
    private $Usager;

    /**
     * @ORM\OneToMany(targetEntity=Vehicule::class, mappedBy="accidents")
     */
    private $Vehicule;

    /**
     * @ORM\ManyToOne(targetEntity=Lieu::class, inversedBy="accidents")
     * @ORM\JoinColumn(nullable=false)
     */
    private $Lieu;

    /**
     * @ORM\ManyToOne(targetEntity=Users::class, inversedBy="accidents")
     */
    private $User;

    /**
     * @ORM\OneToMany(targetEntity=Commentaires::class, mappedBy="accidents")
     */
    private $Commentaires;

    public function __construct()
    {
        $this->Usager = new ArrayCollection();
        $this->Vehicule = new ArrayCollection();
        $this->Commentaires = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDate(): ?\DateTimeInterface
    {
        return $this->Date;
    }

    public function setDate(\DateTimeInterface $Date): self
    {
        $this->Date = $Date;

        return $this;
    }

    public function getNbreTuees(): ?int
    {
        return $this->Nbre_Tuees;
    }

    public function setNbreTuees(?int $Nbre_Tuees): self
    {
        $this->Nbre_Tuees = $Nbre_Tuees;

        return $this;
    }

    public function getNbreUsagers(): ?int
    {
        return $this->Nbre_Usagers;
    }

    public function setNbreUsagers(int $Nbre_Usagers): self
    {
        $this->Nbre_Usagers = $Nbre_Usagers;

        return $this;
    }

    public function getNbreBlesses(): ?int
    {
        return $this->Nbre_Blesses;
    }

    public function setNbreBlesses(?int $Nbre_Blesses): self
    {
        $this->Nbre_Blesses = $Nbre_Blesses;

        return $this;
    }

    public function getNbreVi(): ?int
    {
        return $this->Nbre_Vi;
    }

    public function setNbreVi(int $Nbre_Vi): self
    {
        $this->Nbre_Vi = $Nbre_Vi;

        return $this;
    }

    public function getCarateristiques(): ?Caracteristiques
    {
        return $this->carateristiques;
    }

    public function setCarateristiques(Caracteristiques $carateristiques): self
    {
        $this->carateristiques = $carateristiques;

        return $this;
    }

    /**
     * @return Collection|Usager[]
     */
    public function getUsager(): Collection
    {
        return $this->Usager;
    }

    public function addUsager(Usager $usager): self
    {
        if (!$this->Usager->contains($usager)) {
            $this->Usager[] = $usager;
            $usager->setAccidents($this);
        }

        return $this;
    }

    public function removeUsager(Usager $usager): self
    {
        if ($this->Usager->removeElement($usager)) {
            // set the owning side to null (unless already changed)
            if ($usager->getAccidents() === $this) {
                $usager->setAccidents(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection|Vehicule[]
     */
    public function getVehicule(): Collection
    {
        return $this->Vehicule;
    }

    public function addVehicule(Vehicule $vehicule): self
    {
        if (!$this->Vehicule->contains($vehicule)) {
            $this->Vehicule[] = $vehicule;
            $vehicule->setAccidents($this);
        }

        return $this;
    }

    public function removeVehicule(Vehicule $vehicule): self
    {
        if ($this->Vehicule->removeElement($vehicule)) {
            // set the owning side to null (unless already changed)
            if ($vehicule->getAccidents() === $this) {
                $vehicule->setAccidents(null);
            }
        }

        return $this;
    }

    public function getLieu(): ?Lieu
    {
        return $this->Lieu;
    }

    public function setLieu(?Lieu $Lieu): self
    {
        $this->Lieu = $Lieu;

        return $this;
    }

    /**
     * @return Collection|Commentaires[]
     */
    public function getCommentaires(): Collection
    {
        return $this->Commentaires;
    }

    public function addCommentaire(Commentaires $commentaire): self
    {
        if (!$this->Commentaires->contains($commentaire)) {
            $this->Commentaires[] = $commentaire;
            $commentaire->setAccidents($this);
        }

        return $this;
    }

    public function removeCommentaire(Commentaires $commentaire): self
    {
        if ($this->Commentaires->removeElement($commentaire)) {
            // set the owning side to null (unless already changed)
            if ($commentaire->getAccidents() === $this) {
                $commentaire->setAccidents(null);
            }
        }

        return $this;
    }

    public function getUser(): ?Users
    {
        return $this->User;
    }

    public function setUser(?Users $User): self
    {
        $this->User = $User;

        return $this;
    }
}
