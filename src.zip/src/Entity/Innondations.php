<?php

namespace App\Entity;

use App\Repository\InnondationsRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=InnondationsRepository::class)
 */
class Innondations
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\OneToOne(targetEntity=CaracteristiquesInnondations::class, inversedBy="id_innondations", cascade={"persist", "remove"})
     * @ORM\JoinColumn(nullable=false)
     */
    private $caracteristiques;

    /**
     * @ORM\OneToOne(targetEntity=MenagesPersonnes::class, inversedBy="id_innondations", cascade={"persist", "remove"})
     * @ORM\JoinColumn(nullable=false)
     */
    private $menages_personnes;

    /**
     * @ORM\OneToOne(targetEntity=SurfacesHabitations::class, inversedBy="id_innondations", cascade={"persist", "remove"})
     * @ORM\JoinColumn(nullable=false)
     */
    private $Surfaces_habit;

    /**
     * @ORM\OneToOne(targetEntity=Securite::class, inversedBy="Id_innondations", cascade={"persist", "remove"})
     * @ORM\JoinColumn(nullable=false)
     */
    private $Securite;

    /**
     * @ORM\OneToOne(targetEntity=AutreDegat::class, inversedBy="Id_innondations", cascade={"persist", "remove"})
     */
    private $autre_degat;

    /**
     * @ORM\ManyToOne(targetEntity=Users::class, inversedBy="Id_innondations")
     * @ORM\JoinColumn(nullable=false)
     */
    private $user;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getCaracteristiques(): ?CaracteristiquesInnondations
    {
        return $this->caracteristiques;
    }

    public function setCaracteristiques(CaracteristiquesInnondations $caracteristiques): self
    {
        $this->caracteristiques = $caracteristiques;

        return $this;
    }

    public function getMenagesPersonnes(): ?MenagesPersonnes
    {
        return $this->menages_personnes;
    }

    public function setMenagesPersonnes(MenagesPersonnes $menages_personnes): self
    {
        $this->menages_personnes = $menages_personnes;

        return $this;
    }

    public function getSurfacesHabit(): ?SurfacesHabitations
    {
        return $this->Surfaces_habit;
    }

    public function setSurfacesHabit(SurfacesHabitations $Surfaces_habit): self
    {
        $this->Surfaces_habit = $Surfaces_habit;

        return $this;
    }

    public function getSecurite(): ?Securite
    {
        return $this->Securite;
    }

    public function setSecurite(Securite $Securite): self
    {
        $this->Securite = $Securite;

        return $this;
    }

    public function getAutreDegat(): ?AutreDegat
    {
        return $this->autre_degat;
    }

    public function setAutreDegat(?AutreDegat $autre_degat): self
    {
        $this->autre_degat = $autre_degat;

        return $this;
    }

    public function getUser(): ?Users
    {
        return $this->user;
    }

    public function setUser(?Users $user): self
    {
        $this->user = $user;

        return $this;
    }
}
