<?php

namespace App\Entity;

use App\Repository\SurfacesHabitationsRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=SurfacesHabitationsRepository::class)
 */
class SurfacesHabitations
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Type_habit_atteintes;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    private $Nbre_habit_atteintes;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    private $Nbre_habit_detruites;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    private $age_moy_habit_atteintes;

    /**
     * @ORM\Column(type="boolean")
     */
    private $prox_eau;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $Type_cours_eau_prox;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Surfaces_atteintes;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $Surfaces_detruites;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Type_surf_atteintes;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $Surfaces_cult_atteintes;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $Surfaces_cult_detruites;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $Voies_entre_eau;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $hauteur_eau;

    /**
     * @ORM\OneToOne(targetEntity=Innondations::class, mappedBy="Surfaces_habit", cascade={"persist", "remove"})
     */
    private $id_innondations;


    public function getId(): ?int
    {
        return $this->id;
    }

    public function getTypeHabitAtteintes(): ?string
    {
        return $this->Type_habit_atteintes;
    }

    public function setTypeHabitAtteintes(string $Type_habit_atteintes): self
    {
        $this->Type_habit_atteintes = $Type_habit_atteintes;

        return $this;
    }

    public function getNbreHabitAtteintes(): ?int
    {
        return $this->Nbre_habit_atteintes;
    }

    public function setNbreHabitAtteintes(?int $Nbre_habit_atteintes): self
    {
        $this->Nbre_habit_atteintes = $Nbre_habit_atteintes;

        return $this;
    }

    public function getNbreHabitDetruites(): ?int
    {
        return $this->Nbre_habit_detruites;
    }

    public function setNbreHabitDetruites(?int $Nbre_habit_detruites): self
    {
        $this->Nbre_habit_detruites = $Nbre_habit_detruites;

        return $this;
    }

    public function getAgeMoyHabitAtteintes(): ?int
    {
        return $this->age_moy_habit_atteintes;
    }

    public function setAgeMoyHabitAtteintes(?int $age_moy_habit_atteintes): self
    {
        $this->age_moy_habit_atteintes = $age_moy_habit_atteintes;

        return $this;
    }

    public function getProxEau(): ?bool
    {
        return $this->prox_eau;
    }

    public function setProxEau(bool $prox_eau): self
    {
        $this->prox_eau = $prox_eau;

        return $this;
    }

    public function getTypeCoursEauProx(): ?string
    {
        return $this->Type_cours_eau_prox;
    }

    public function setTypeCoursEauProx(?string $Type_cours_eau_prox): self
    {
        $this->Type_cours_eau_prox = $Type_cours_eau_prox;

        return $this;
    }

    public function getSurfacesAtteintes(): ?string
    {
        return $this->Surfaces_atteintes;
    }

    public function setSurfacesAtteintes(string $Surfaces_atteintes): self
    {
        $this->Surfaces_atteintes = $Surfaces_atteintes;

        return $this;
    }

    public function getSurfacesDetruites(): ?string
    {
        return $this->Surfaces_detruites;
    }

    public function setSurfacesDetruites(?string $Surfaces_detruites): self
    {
        $this->Surfaces_detruites = $Surfaces_detruites;

        return $this;
    }

    public function getTypeSurfAtteintes(): ?string
    {
        return $this->Type_surf_atteintes;
    }

    public function setTypeSurfAtteintes(string $Type_surf_atteintes): self
    {
        $this->Type_surf_atteintes = $Type_surf_atteintes;

        return $this;
    }

    public function getSurfacesCultAtteintes(): ?string
    {
        return $this->Surfaces_cult_atteintes;
    }

    public function setSurfacesCultAtteintes(?string $Surfaces_cult_atteintes): self
    {
        $this->Surfaces_cult_atteintes = $Surfaces_cult_atteintes;

        return $this;
    }

    public function getSurfacesCultDetruites(): ?string
    {
        return $this->Surfaces_cult_detruites;
    }

    public function setSurfacesCultDetruites(?string $Surfaces_cult_detruites): self
    {
        $this->Surfaces_cult_detruites = $Surfaces_cult_detruites;

        return $this;
    }

    public function getVoiesEntreEau(): ?string
    {
        return $this->Voies_entre_eau;
    }

    public function setVoiesEntreEau(?string $Voies_entre_eau): self
    {
        $this->Voies_entre_eau = $Voies_entre_eau;

        return $this;
    }

    public function getHauteurEau(): ?string
    {
        return $this->hauteur_eau;
    }

    public function setHauteurEau(string $hauteur_eau): self
    {
        $this->hauteur_eau = $hauteur_eau;

        return $this;
    }

    public function getIdInnondation(): ?Innondation
    {
        return $this->Id_innondation;
    }

    public function setIdInnondation(Innondation $Id_innondation): self
    {
        // set the owning side of the relation if necessary
        if ($Id_innondation->getSurfacesHabitations() !== $this) {
            $Id_innondation->setSurfacesHabitations($this);
        }

        $this->Id_innondation = $Id_innondation;

        return $this;
    }


    public function getIdInnondations(): ?Innondations
    {
        return $this->id_innondations;
    }

    public function setIdInnondations(Innondations $id_innondations): self
    {
        // set the owning side of the relation if necessary
        if ($id_innondations->getSurfacesHabit() !== $this) {
            $id_innondations->setSurfacesHabit($this);
        }

        $this->id_innondations = $id_innondations;

        return $this;
    }
}
