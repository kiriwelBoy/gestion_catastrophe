<?php

namespace App\Entity;

use App\Repository\SecuriteRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=SecuriteRepository::class)
 */
class Securite
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="boolean")
     */
    private $Canalisation;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $Securite;

    /**
     * @ORM\Column(type="boolean")
     */
    private $Stagnation_eau;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $Type_sol;

    /**
     * @ORM\OneToOne(targetEntity=Innondations::class, mappedBy="Securite", cascade={"persist", "remove"})
     */
    private $Id_innondations;



    public function getId(): ?int
    {
        return $this->id;
    }

    public function getCanalisation(): ?bool
    {
        return $this->Canalisation;
    }

    public function setCanalisation(bool $Canalisation): self
    {
        $this->Canalisation = $Canalisation;

        return $this;
    }

    public function getSecurite(): ?string
    {
        return $this->Securite;
    }

    public function setSecurite(?string $Securite): self
    {
        $this->Securite = $Securite;

        return $this;
    }

    public function getStagnationEau(): ?bool
    {
        return $this->Stagnation_eau;
    }

    public function setStagnationEau(bool $Stagnation_eau): self
    {
        $this->Stagnation_eau = $Stagnation_eau;

        return $this;
    }

    public function getTypeSol(): ?string
    {
        return $this->Type_sol;
    }

    public function setTypeSol(?string $Type_sol): self
    {
        $this->Type_sol = $Type_sol;

        return $this;
    }

    public function getIdInnondations(): ?Innondations
    {
        return $this->Id_innondations;
    }

    public function setIdInnondations(Innondations $Id_innondations): self
    {
        // set the owning side of the relation if necessary
        if ($Id_innondations->getSecurite() !== $this) {
            $Id_innondations->setSecurite($this);
        }

        $this->Id_innondations = $Id_innondations;

        return $this;
    }

}
