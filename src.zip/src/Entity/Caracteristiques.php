<?php

namespace App\Entity;

use App\Repository\CaracteristiquesRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=CaracteristiquesRepository::class)
 */
class Caracteristiques
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="date")
     */
    private $dateAccident;

    /**
     * @ORM\Column(type="time")
     */
    private $Heure;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Luminiosite;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Departement;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Commune;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $agglomeration;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $intersection;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Atm;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $Collision;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Adresse;

    /**
     * @ORM\Column(type="float")
     */
    private $Latitude;

    /**
     * @ORM\Column(type="float")
     */
    private $Longitude;


    /**
     * @ORM\OneToOne(targetEntity=Accident::class, mappedBy="caracteristiques", cascade={"persist", "remove"})
     */
    private $accident;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDepartement(): ?string
    {
        return $this->Departement;
    }

    public function setDepartement(string $Departement): self
    {
        $this->Departement = $Departement;

        return $this;
    }

    public function getCommune(): ?string
    {
        return $this->Commune;
    }

    public function setCommune(string $Commune): self
    {
        $this->Commune = $Commune;

        return $this;
    }



    public function getIntersection(): ?string
    {
        return $this->intersection;
    }

    public function setIntersection(?string $intersection): self
    {
        $this->intersection = $intersection;

        return $this;
    }

    public function getAtm(): ?string
    {
        return $this->Atm;
    }

    public function setAtm(string $Atm): self
    {
        $this->Atm = $Atm;

        return $this;
    }

    public function getCollision(): ?string
    {
        return $this->Collision;
    }

    public function setCollision(?string $Collision): self
    {
        $this->Collision = $Collision;

        return $this;
    }

    public function getAdresse(): ?string
    {
        return $this->Adresse;
    }

    public function setAdresse(string $Adresse): self
    {
        $this->Adresse = $Adresse;

        return $this;
    }

    public function getLatitude(): ?float
    {
        return $this->Latitude;
    }

    public function setLatitude(float $Latitude): self
    {
        $this->Latitude = $Latitude;

        return $this;
    }

    public function getLongitude(): ?float
    {
        return $this->Longitude;
    }

    public function setLongitude(float $Longitude): self
    {
        $this->Longitude = $Longitude;

        return $this;
    }

    public function getLuminiosite(): ?string
    {
        return $this->Luminiosite;
    }

    public function setLuminiosite(string $Luminiosite): self
    {
        $this->Luminiosite = $Luminiosite;

        return $this;
    }


    public function getAccident(): ?Accident
    {
        return $this->accident;
    }

    public function setAccident(Accident $accident): self
    {
        // set the owning side of the relation if necessary
        if ($accident->getCaracteristiques() !== $this) {
            $accident->setCaracteristiques($this);
        }

        $this->accident = $accident;

        return $this;
    }

    public function getAgglomeration(): ?string
    {
        return $this->agglomeration;
    }

    public function setAgglomeration(string $agglomeration): self
    {
        $this->agglomeration = $agglomeration;

        return $this;
    }

    public function getDateAccident(): ?\DateTimeInterface
    {
        return $this->dateAccident;
    }

    public function setDateAccident(\DateTimeInterface $dateAccident): self
    {
        $this->dateAccident = $dateAccident;

        return $this;
    }

    public function getHeure(): ?\DateTimeInterface
    {
        return $this->Heure;
    }

    public function setHeure(\DateTimeInterface $Heure): self
    {
        $this->Heure = $Heure;

        return $this;
    }


}
