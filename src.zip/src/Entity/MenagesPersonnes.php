<?php

namespace App\Entity;

use App\Repository\MenagesPersonnesRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=MenagesPersonnesRepository::class)
 */
class MenagesPersonnes
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    private $Nbre_Men_atteints;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    private $Nbre_Men_Sinistre;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    private $Nbre_Morts;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    private $Nbre_blesse;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    private $Nbre_Sinistre;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    private $Nbre_victimes;

    /**
     * @ORM\OneToOne(targetEntity=Innondations::class, mappedBy="menages_personnes", cascade={"persist", "remove"})
     */
    private $id_innondations;


    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNbreMenAtteints(): ?int
    {
        return $this->Nbre_Men_atteints;
    }

    public function setNbreMenAtteints(?int $Nbre_Men_atteints): self
    {
        $this->Nbre_Men_atteints = $Nbre_Men_atteints;

        return $this;
    }

    public function getNbreMenSinistre(): ?int
    {
        return $this->Nbre_Men_Sinistre;
    }

    public function setNbreMenSinistre(?int $Nbre_Men_Sinistre): self
    {
        $this->Nbre_Men_Sinistre = $Nbre_Men_Sinistre;

        return $this;
    }

    public function getNbreMorts(): ?int
    {
        return $this->Nbre_Morts;
    }

    public function setNbreMorts(?int $Nbre_Morts): self
    {
        $this->Nbre_Morts = $Nbre_Morts;

        return $this;
    }

    public function getNbreBlesse(): ?int
    {
        return $this->Nbre_blesse;
    }

    public function setNbreBlesse(?int $Nbre_blesse): self
    {
        $this->Nbre_blesse = $Nbre_blesse;

        return $this;
    }

    public function getNbreSinistre(): ?int
    {
        return $this->Nbre_Sinistre;
    }

    public function setNbreSinistre(?int $Nbre_Sinistre): self
    {
        $this->Nbre_Sinistre = $Nbre_Sinistre;

        return $this;
    }

    public function getNbreVictimes(): ?int
    {
        return $this->Nbre_victimes;
    }

    public function setNbreVictimes(?int $Nbre_victimes): self
    {
        $this->Nbre_victimes = $Nbre_victimes;

        return $this;
    }

    public function getIdInnondations(): ?Innondations
    {
        return $this->id_innondations;
    }

    public function setIdInnondations(Innondations $id_innondations): self
    {
        // set the owning side of the relation if necessary
        if ($id_innondations->getMenagesPersonnes() !== $this) {
            $id_innondations->setMenagesPersonnes($this);
        }

        $this->id_innondations = $id_innondations;

        return $this;
    }


}
