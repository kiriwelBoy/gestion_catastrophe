<?php

namespace App\Form;

use App\Entity\Lieu;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;

class LieuType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('num_route', TextType::class, [
                    'label' => 'Numéro de la route'
                ])
            ->add('regime_circ', ChoiceType::class, [
                    'label' => 'Régime de circulation',
                    'choices' => [
                        'Non renseignée' => 'Non renseignée',
                        'A sens unique'  => 'A sens unique',
                        'Bidirectionnelle'=> 'Bidirectionnelle',
                        'A chaussées séparées' => 'A chaussées séparées',
                        'Avec voies d’affectation variable' => 'Avec voies d’affectation variable',
                    ]
                ])
            ->add('categprie_route', ChoiceType::class, [
                    'label' => 'Catégorie de la route',
                    'choices' =>   [
                        'Autoroute'                                              => 'Autoroute',
                        'Route nationale'                                        => 'Route nationale',
                        'Route Départementale'                                   => 'Route Départementale',
                        'Voie Communales'                                        => 'Voie Communales',
                        'Hors réseau public'                                     => 'Hors réseau public',
                        'Parc de stationnement ouvert à la circulation publique' => 'Parc de stationnement ouvert à la circulation publique',
                        'Routes de métropole urbaine'                            => 'Routes de métropole urbaine',
                        'Autre'                                                  =>'Autre',
                    ]
                ])
            ->add('nbTotVoie', IntegerType::class, [
                    'label' => 'Nombre total de voies de circulation',

                ])
            ->add('signale', ChoiceType::class, [
                    'label' =>  'Signale l’existence d’une voie réservée, indépendamment du fait que l’accident ait lieu ou non sur cette voie',
                    'choices' =>[
                        'Non renseignée' => 'Non renseignée',
                        'Sans objet'     => 'Sans objet',
                        'Piste cyclable' => 'Piste cyclable',
                        'Bande cyclable' => 'Bande cyclable',
                        'Voie réservée'  => 'Voie réservée',
                    ]
                ])
            ->add('profile', ChoiceType::class, [
                    'label'   =>  'Profil en long décrit la déclivité de la route à l\'endroit de l\'accident',
                    'choices' =>[
                        'Non renseignée'    => 'Non renseignée',
                        'Plat'              => 'Plat',
                        'Pente'             => 'Pente',
                        'Sommet de côte'    => 'Sommet de côte',
                        'Bas de côte'       => 'Bas de côte',
                    ]
                ])
            ->add('numPR', IntegerType::class, [
                'label' => 'Numéro du PR de rattachement (numéro de la borne amont). La valeur -1 signifie que le PR n’est pas renseigné',
                ])
            ->add('distance', IntegerType::class, [
                'label'   =>  'Distance en mètres au PR (par rapport à la borne amont). La valeur -1 signifie que le PR n’est pas renseigné',
                ])
            ->add('tracePlan', ChoiceType::class, [
                'label'   =>  'Tracé en plan',
                'choices' =>[
                        'Non renseignée'        => 'Non renseignée',
                        'Partie rectiligne'     => 'Partie rectiligne',
                        'En courbe à gauche'    => 'En courbe à gauche',
                        'En courbe à droite'    => 'En courbe à droite',
                        'En « S »'              => 'En « S »',
                    ]
                ])
            ->add('largeur', IntegerType::class, [
                'label' => 'Largeur du terre-plein central (TPC) s\'il existe (en m)'                    
                ])
            ->add('largeur1', IntegerType::class, [
                'label' => 'Largeur de la chaussée affectée à la circulation des véhicules ne sont pas compris les bandes d\'arrêt d\'urgence, les TPC et les places de stationnement (en m)'                    
                ])
            ->add('etatSurface', ChoiceType::class, [
                'label'   =>  'Etat de la surface',
                'choices' =>[
                    'Non renseignée'        => 'Non renseignée',
                    'Normale'     => 'Normale',
                    'Mouillée'    => 'Mouillée',
                    'Flaques'    => 'Flaques',
                    'Inondée'    => 'Inondée',
                    'Enneigée'    => 'Enneigée',
                    'Boue'    => 'Boue',
                    'Boue'    => 'Boue',
                    'Corps gras'    => 'Corps gras',
                    'huile'    => 'huile',
                    'Autre'    => 'Autre',
                    ]
                ])
            ->add('amenagement')
            ->add('situation')
            ->add('vmax')
        //->add('save', SubmitType::class, array('label'=> 'Ajouter'))
    ;           
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Lieu::class,
        ]);
    }
}
