<?php

namespace App\Form;

use App\Entity\CaracteristiquesIncendies;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\TimeType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;

class CaracteristiqueIncendieType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
        ->add('region', TextType::class, [
            'label' => 'Région'
        ])
        ->add('departement', TextType::class, [
            'label' => 'Département'
        ])
        ->add('commune', TextType::class, [
            'label' => 'Commune'
        ])
        ->add('latitude', NumberType::class, [
            'label' => 'Latitude'
        ])
        ->add('longitude', NumberType::class, [
            'label' => 'Longitude'
        ])
        ->add('typeFeu', ChoiceType::class, [
            'label' => 'Type de feu',
            'choices' => [
                'forêt' => 'forêt',
                'domestique' => 'domestique',
            ]
        ])
        ->add('dateDebut', DateType::class, [
            'label' => 'Date de début',
        ])
        ->add('heureDebut', TimeType::class, [
            'label' => 'Heure de début',
        ])
        ->add('dateFin', DateType::class, [
            'label' => 'Date de fin',
        ])
        ->add('heureFin', TimeType::class, [
            'label' => 'Heure de fin',
        ])           
    ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => CaracteristiquesIncendies::class,
        ]);
    }
}
