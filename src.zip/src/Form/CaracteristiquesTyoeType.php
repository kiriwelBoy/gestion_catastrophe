<?php

namespace App\Form;

use App\Entity\Caracteristiques;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\TimeType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;

class CaracteristiquesTyoeType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('dateAccident', DateType::class,[
                    'label' =>'Date de l\'accident'
                ])
            ->add('Heure', TimeType::class,[
                    'label'   => 'Heure de l\'accident' 
                ])
            ->add('Departement', TextType::class, [
                    'label' => "Département"
                ])
            ->add('Commune', TextType::class, [
                    'label' => 'Commune'
                ])
            ->add('Adresse', TextType::class, [
                    'label' => 'Addresse'
                ])
            ->add('Longitude',  NumberType::class, [
                    'label' => 'Longitude'
                ])
            ->add('Latitude', NumberType::class, [
                    'label' => 'Latitude'
                ])
            ->add('Luminiosite', ChoiceType::class, [
                    'label'   => 'Lumière',
                    'choices' =>[
                        'Plein jour'                            =>'Plein jour',
                        'Crépuscule ou aube'                    => 'Crépuscule ou aube',
                        'Nuit sans éclairage public'            =>'Nuit sans éclairage public',
                        'Nuit avec éclairage public non allumé' => 'Nuit avec éclairage public non allumé',
                        'Nuit avec éclairage public allumé'     => 'Nuit avec éclairage public allumé',
                    ]
                ])

            ->add('agglomeration',  ChoiceType::class, [
                    'choices' =>[
                        'Agglomération'      => 'Agglomération',
                        'Hors agglomération' => 'Hors agglomération',
                    ]
                ])
            ->add('intersection', ChoiceType::class, [
                    'label'   => 'Intersection',
                    'choices' =>[
                        'Hors intersection'                 => 'Hors intersection',
                        'Intersection en X'                 => 'Intersection en X',
                        'Intersection en T'                 => 'Intersection en T',
                        'Intersection en Y'                 => 'Intersection en Y',
                        'Intersection à plus de 4 branches' => 'Intersection à plus de 4 branches',
                        'Giratoire'                         => 'Giratoire',
                        'Place'                             => 'Place',
                        'Passage à niveau'                  => 'Passage à niveau',
                        'Autre intersection'                => 'Autre intersection'
                    ]
                ])
            ->add('Atm', ChoiceType::class, [
                    'label'   => 'Conditions atmosphérique',
                    'choices' =>[
                        'Non renseignée'        => 'Non renseignée',
                        'Normale'               => 'Normale',
                        'Pluie légère'          => 'Pluie légère',
                        'Pluie forte'           => 'Pluie forte',
                        'Neige - grêle'         => 'Neige - grêle',
                        'Brouillard - fumée'    => 'Brouillard - fumée',
                        'Vent fort - tempête'   => 'Vent fort - tempête',
                        'Temps éblouissant'     => 'Temps éblouissant',
                        'Temps couvert'         => 'Temps couvert',
                        'Autre'                 => 'Autre'
                    ]
                ])
            ->add('Collision', ChoiceType::class, [
                    'label'   => 'Type de collision',
                    'choices' =>[
                        'Non renseignée'                                => "Non renseignée",
                        'Deux véhicules - frontale'                     => 'Deux véhicules - frontale',
                        'Deux véhicules – par l’arrière'                => 'Deux véhicules – par l’arrière',
                        'Deux véhicules – par le coté'                  => 'Deux véhicules – par le coté',
                        'Trois véhicules et plus – en chaîne'           => 'Trois véhicules et plus – en chaîne',
                        'Trois véhicules et plus - collisions multiples'=> 'Trois véhicules et plus - collisions multiples',
                        'Autre collision'                               => 'Autre collision',
                        'Sans collision'                                => 'Sans collision',
                    ]
                ])

        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Caracteristiques::class,
        ]);
    }
}
