<?php

namespace App\Form;

use App\Entity\Incendie;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use App\Form\CaracteristiqueIncendieType;
use App\Form\InfoTempIntervType;
use App\Form\InfoSpatialeType;
use App\Form\DonMeteoType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;

class IncendieType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('caracteristique', CaracteristiqueIncendieType::class, [
                'label' => 'CARACTÉRISTIQUE'
            ])
            ->add('info_temp_interv', InfoTempIntervType::class, [
                'label' => 'INFORMATIONS TEMPORELLES SUR L\'INTERVENTION '
            ])
            ->add('Infospatiale', InfoSpatialeType::class, [
                'label' => 'INFORMATIONS SPATIALES'
            ])
            ->add('donneeMeteo', DonMeteoType::class, [
                'label' => 'DONNÉES MÉTÉOLOGIQUE'
            ])
            ->add('save', SubmitType::class, array('label'=> 'Envoyer'))
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Incendie::class,
        ]);
    }
}
