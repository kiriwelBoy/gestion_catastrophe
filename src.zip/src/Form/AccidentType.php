<?php

namespace App\Form;

use App\Entity\Accident;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use App\Form\CaracteristiqueTyoeType;
use App\Form\LieuType;
use App\Form\VehiculeType;
use App\Form\UsagerType;

class AccidentType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('caracteristiques',CaracteristiquesTyoeType::class)
            ->add('Lieu',LieuType::class)   
            ->add('Vehicule', CollectionType::class, [
                'entry_type' => VehiculeType::class,
                'entry_options' =>['label' => false],
                'allow_add'      => true,
                'allow_delete'  => true
            ]) 
            ->add('Usager', CollectionType::class, [
                'entry_type' => UsagerType::class,
                'entry_options' =>['label' => false],
                'allow_add'      => true,
                'allow_delete'  => true
            ])        
            ->add('save', SubmitType::class, array('label' => 'Envoyer'))
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Accident::class,
        ]);
    }
}
