<?php

namespace App\Repository;

use App\Entity\CompteModerateur;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @method CompteModerateur|null find($id, $lockMode = null, $lockVersion = null)
 * @method CompteModerateur|null findOneBy(array $criteria, array $orderBy = null)
 * @method CompteModerateur[]    findAll()
 * @method CompteModerateur[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class CompteModerateurRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, CompteModerateur::class);
    }

    // /**
    //  * @return CompteModerateur[] Returns an array of CompteModerateur objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('c')
            ->andWhere('c.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('c.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?CompteModerateur
    {
        return $this->createQueryBuilder('c')
            ->andWhere('c.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
