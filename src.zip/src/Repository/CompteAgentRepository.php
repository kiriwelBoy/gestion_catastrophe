<?php

namespace App\Repository;

use App\Entity\CompteAgent;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @method CompteAgent|null find($id, $lockMode = null, $lockVersion = null)
 * @method CompteAgent|null findOneBy(array $criteria, array $orderBy = null)
 * @method CompteAgent[]    findAll()
 * @method CompteAgent[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class CompteAgentRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, CompteAgent::class);
    }

    // /**
    //  * @return CompteAgent[] Returns an array of CompteAgent objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('c')
            ->andWhere('c.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('c.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?CompteAgent
    {
        return $this->createQueryBuilder('c')
            ->andWhere('c.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
