<?php

namespace App\Repository;

use App\Entity\CompteAdmin;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @method CompteAdmin|null find($id, $lockMode = null, $lockVersion = null)
 * @method CompteAdmin|null findOneBy(array $criteria, array $orderBy = null)
 * @method CompteAdmin[]    findAll()
 * @method CompteAdmin[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class CompteAdminRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, CompteAdmin::class);
    }

    // /**
    //  * @return CompteAdmin[] Returns an array of CompteAdmin objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('c')
            ->andWhere('c.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('c.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?CompteAdmin
    {
        return $this->createQueryBuilder('c')
            ->andWhere('c.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
