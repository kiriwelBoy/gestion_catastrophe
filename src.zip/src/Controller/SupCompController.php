<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
/**
 * @IsGranted("ROLE_SCOMP")
 * @Route("/SupComp", name="scomp_")
 */
class SupCompController extends AbstractController
{

    /**
     * @Route("/home", name="home")
     */
    public function home(){
        return $this->render('app/accueil.html.twig');        
    }

    /**
     * @Route("/Rapports", name="Rapports")
     */
    public function rapports(){
        $user = $this->getUser();
        $accident = $user->getAccidentsregis();
        return $this->render("adj_comp/rapports.html.twig",[
            'accidents' => $accident
        ]);
    }
    
    /**
     * @Route("/Notifications", name="Notif")
     */
    public function notif(){
        return $this->render('sup_comp/notif.html.twig');
    }

    /**
     * @Route("/Profil", name="Profil")
     */
    public function profil(){
        return $this->render('sup_comp/profil.html.twig');
    }

    /**
     * Modifier Profile
     * @Route("/Profil/Modifier_profil", name="modif_Pro")
     */
    public function modifPro(Request $request){
        $user = $this->getUser();
        $form = $this->createForm(ModifProfilFormType::class, $user);
                    /*->add('nom', TextType::class)
                    ->add('prenom', TextType::class)
                    ->add('adresse', EmailType::class)
                    ->add('telephone');*/
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
// encode the plain password
/*$user->setPassword(
    $passwordEncoder->encodePassword(
        $user,
        $form->get('plainPassword')->getData()
    )
);
$user->setStatusCompte('Actif');
$user->setRoles(["ROLE_AGENT"]);*/

            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($user);
            $entityManager->flush();
// do anything else you need here, like send an email

            $this->addFlash('message','Profil mis à jour');
            return $this->redirectToRoute('scomp_Profil');
        }

        return $this->render('sup_comp/modifpro.html.twig', [
            'modifForm' => $form->createView(),
            ]);
    }

    /**
     * Modifier Mot de passe
     * @Route("/Profil/Modifier_passe", name="modif_Pass")
     */
    public function modifPass(Request $request, UserPasswordEncoderInterface $passwordEncoder){
       if($request->isMethod('POST')){
            $manager = $this->getDoctrine()->getManager();

            $user = $this->getUser();

            if($request->request->get('pass') == $request->request->get('confirmPass')){
                $user->setPassword(
                    $passwordEncoder->encodePassword(
                        $user,
                        $request->request->get('pass')
                    ));
                    $manager->flush();
                    $this->addFlash('message','Mot de passe modifié avec succès');

                    return $this->redirectToRoute('scomp_Profil');
            } else{
                $this->addFlash('error', 'Veuillez saisir deux mot de passe identiques');
            }
        }
        return $this->render('sup_comp/modifPass.html.twig');
    }   

}
