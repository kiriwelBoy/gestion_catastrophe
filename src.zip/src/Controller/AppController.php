<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Doctrine\ORM\EntityManagerInterface;

use App\Entity\CompteAgent;
use App\Repository\CompteAgentRepository;
class AppController extends AbstractController
{
    /**
     * @Route("/", name="home")
     */
    public function home() {
        return $this->render('app/home.html.twig');
    }

    /**
     * @Route("/roles", name="roles")
     *
     */
    public function roles() {
        if ($this->isGranted('ROLE_ADMIN')){ 
            $route='admin_home';
        }
        elseif ($this->isGranted('ROLE_MODER')){
            $route='moder_home';
        }
        elseif ($this->isGranted('ROLE_ADSYS')){
            $route='adminsys_home';
        }
        elseif ($this->isGranted('ROLE_ACOMP')){
            if($this->getUser()->getStatusCompte() == "Actif"){
                $route='acomp_home'; }
            else {
                $route = 'stop';
            }
        }
        elseif ($this->isGranted('ROLE_SCOMP')){
            if($this->getUser()->getStatusCompte() == "Actif"){
                $route='scomp_home'; }
            else {
                $route = 'stop';
            }
        }
        elseif ($this->isGranted('ROLE_APREF')){
            if($this->getUser()->getStatusCompte() == "Actif"){
                $route='apref_home'; }
            else {
                $route = 'stop';
            }
        }
        elseif ($this->isGranted('ROLE_AGOUV')){
            if($this->getUser()->getStatusCompte() == "Actif"){
                $route='agouv_home'; }
            else {
                $route = 'stop';
            }
        }
        else{
            if($this->getUser()->getStatusCompte() == "Actif"){
                $route='agent_home'; }
            else {
                $route = 'stop';
            }
        }
        return $this->redirectToRoute($route);

    }
   
    /**
     * @Route("/stop", name="stop")
     */
    public function Stop() {
        return new Response("Désolé vous ne pouvez pas vous connecter, veuillez contacter l'administrateur.");
    }    
}