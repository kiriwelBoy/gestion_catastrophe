<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
/**
 * @IsGranted("ROLE_ACOMP")
 * @Route("/AdjComp", name="acomp_")
 */
class AdjCompController extends AbstractController
{
    /**
     * @Route("/home", name="home")
     */
    public function home(){
        return $this->render('app/accueil.html.twig');        
    }

    /**
     * @Route("/Rediger_Rapport_Accident", name="R_R_A")
     */
    public function rapportA(){
        return $this->render('adj_comp/rediger_rap_a.html.twig');
    }

    /**
     * @Route("/Rediger_Rapport_Innondation", name="R_R_I")
     */
    public function rapportIno(){
        return $this->render('adj_comp/rediger_rap_ino.html.twig');
    }

    /**
     * @Route("/Rediger_Rapport_Incendie", name="R_R_Inc")
     */
    public function rapportInc(){
        return $this->render('adj_comp/rediger_rap_inc.html.twig');
    }

    /**
     * @Route("/Rapports", name="Rapports")
     */
    public function rapports(){
        $user = $this->getUser();
        $accident = $user->getAccidentsregis();
        return $this->render("adj_comp/rapports.html.twig",[
            'accidents' => $accident
        ]);
    }

    /**
     * @Route("/Notifications", name="Notif")
     */
    public function notif(){
        return $this->render('adj_comp/notif.html.twig');
    }

    /**
     * @Route("/Profil", name="Profil")
     */
    public function profil(){
        return $this->render('adj_comp/profil.html.twig');
    }

    /**
     * Modifier Profile
     * @Route("/Profil/Modifier_profil", name="modif_Pro")
     */
    public function modifPro(Request $request){
        $user = $this->getUser();
        $form = $this->createForm(ModifProfilFormType::class, $user);
                    /*->add('nom', TextType::class)
                    ->add('prenom', TextType::class)
                    ->add('adresse', EmailType::class)
                    ->add('telephone');*/
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
// encode the plain password
/*$user->setPassword(
    $passwordEncoder->encodePassword(
        $user,
        $form->get('plainPassword')->getData()
    )
);
$user->setStatusCompte('Actif');
$user->setRoles(["ROLE_AGENT"]);*/

            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($user);
            $entityManager->flush();
// do anything else you need here, like send an email

            $this->addFlash('message','Profil mis à jour');
            return $this->redirectToRoute('acomp_Profil');
        }

        return $this->render('adj_comp/modifpro.html.twig', [
            'modifForm' => $form->createView(),
            ]);
    }

    /**
     * Modifier Mot de passe
     * @Route("/Profil/Modifier_passe", name="modif_Pass")
     */
    public function modifPass(Request $request, UserPasswordEncoderInterface $passwordEncoder){
       if($request->isMethod('POST')){
            $manager = $this->getDoctrine()->getManager();

            $user = $this->getUser();

            if($request->request->get('pass') == $request->request->get('confirmPass')){
                $user->setPassword(
                    $passwordEncoder->encodePassword(
                        $user,
                        $request->request->get('pass')
                    ));
                    $manager->flush();
                    $this->addFlash('message','Mot de passe modifié avec succès');

                    return $this->redirectToRoute('acomp_Profil');
            } else{
                $this->addFlash('error', 'Veuillez saisir deux mot de passe identiques');
            }
        }
        return $this->render('adj_comp/modifPass.html.twig');
    }    
    
}
