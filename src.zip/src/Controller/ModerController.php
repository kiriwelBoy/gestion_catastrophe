<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Symfony\Component\Security\Core\Encoder\UserPasswordEncoderInterface;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use App\Form\ModifProfilFormType;
use App\Entity\Users;
use App\Repository\UsersRepository;
use App\Repository\AccidentRepository;
/**
 * @IsGranted("ROLE_MODER")
 * @Route("/moder", name="moder_")
 */
class ModerController extends AbstractController
{
    /**
     * @Route("/home", name="home")
     */
    public function home(){
        return $this->render('app/accueil.html.twig');        
    }

    /**
     * @Route("/Notifications", name="Notif")
     */
    public function notif(){
        return $this->render('moder/notif.html.twig');
    }

    /**
     * @Route("/Profil", name="Profil")
     */
    public function profil(){
        return $this->render('moder/profil.html.twig');
    }

    /**
     * @Route("/Compte_rendus", name="Cr")
     */
    public function cr(UsersRepository $usersenfant) {
        $user = $this->getUser();
        $accidents = array();
        $userenfanttri = $usersenfant->findByIdResp($user->getId());
        foreach($userenfanttri as $users)
            {
                $accidents[] = $users->getAccidentsregis();
            }
        return $this->render('moder/cr.html.twig',[
            'accidents' => $accidents
        
        ]);
    }

    /**
     * Lister les comptes Agents
     * @Route("/agents", name="agents")
     */
    public function usersList(UsersRepository $usersenfant){
        $user = $this->getUser();
        return $this->render("moder/users.html.twig",[
            'users' => $usersenfant->findByIdResp($user->getId())
        ]);
    }

    /**
     * Modifier Profile
     * @Route("/Profil/Modifier_profil", name="modif_Pro")
     */
    public function modifPro(Request $request){
        $user = $this->getUser();
        $form = $this->createForm(ModifProfilFormType::class, $user);
                    /*->add('nom', TextType::class)
                    ->add('prenom', TextType::class)
                    ->add('adresse', EmailType::class)
                    ->add('telephone');*/
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
// encode the plain password
/*$user->setPassword(
    $passwordEncoder->encodePassword(
        $user,
        $form->get('plainPassword')->getData()
    )
);
$user->setStatusCompte('Actif');
$user->setRoles(["ROLE_AGENT"]);*/

            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($user);
            $entityManager->flush();
// do anything else you need here, like send an email

            $this->addFlash('message','Profil mis à jour');
            return $this->redirectToRoute('Profil');
        }

        return $this->render('moder/modifpro.html.twig', [
            'modifForm' => $form->createView(),
            ]);
    }

    /**
     * Modifier Mot de passe
     * @Route("/Profil/Modifier_passe", name="modif_Pass")
     */
    public function modifPass(Request $request, UserPasswordEncoderInterface $passwordEncoder){
       if($request->isMethod('POST')){
            $manager = $this->getDoctrine()->getManager();

            $user = $this->getUser();

            if($request->request->get('pass') == $request->request->get('confirmPass')){
                $user->setPassword(
                    $passwordEncoder->encodePassword(
                        $user,
                        $request->request->get('pass')
                    ));
                    $manager->flush();
                    $this->addFlash('message','Mot de passe modifié avec succès');

                    return $this->redirectToRoute('moder_Profil');
            } else{
                $this->addFlash('error', 'Veuillez saisir deux mot de passe identiques');
            }
        }
        return $this->render('moder/modifPass.html.twig');
    }
}
