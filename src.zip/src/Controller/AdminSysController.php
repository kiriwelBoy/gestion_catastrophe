<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Encoder\UserPasswordEncoderInterface;
use Doctrine\ORM\EntityManagerInterface;
use App\Form\ModifProfilFormType;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Repository\UsersRepository;
use App\Entity\Users;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
/**
 * @IsGranted("ROLE_ADSYS")
 * @Route("/sysad", name="adminsys_")
 */
class AdminSysController extends AbstractController
{
    /**
     * @Route("/home", name="home")
     */
    public function home(){
        return $this->render('app/accueil.html.twig');        
    }

    /**
     * @Route("/Profil", name="Profil")
     */
    public function profil(){
        return $this->render('admin_sys/profil.html.twig');
    }

    /**
     * Modifier Profile
     * @Route("/Profil/Modifier_profil", name="modif_Pro")
     */
    public function modifPro(Request $request){
        $user = $this->getUser();
        $form = $this->createForm(ModifProfilFormType::class, $user);
                    /*->add('nom', TextType::class)
                    ->add('prenom', TextType::class)
                    ->add('adresse', EmailType::class)
                    ->add('telephone');*/
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
// encode the plain password
/*$user->setPassword(
    $passwordEncoder->encodePassword(
        $user,
        $form->get('plainPassword')->getData()
    )
);
$user->setStatusCompte('Actif');
$user->setRoles(["ROLE_AGENT"]);*/

            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($user);
            $entityManager->flush();
// do anything else you need here, like send an email

            $this->addFlash('message','Profil mis à jour');
            return $this->redirectToRoute('adminsys_Profil');
        }

        return $this->render('admin_sys/modifpro.html.twig', [
            'modifForm' => $form->createView(),
            ]);
    }

    /**
     * Modifier Mot de passe
     * @Route("/Profil/Modifier_passe", name="modif_Pass")
     */
    public function modifPass(Request $request, UserPasswordEncoderInterface $passwordEncoder){
       if($request->isMethod('POST')){
            $manager = $this->getDoctrine()->getManager();

            $user = $this->getUser();

            if($request->request->get('pass') == $request->request->get('confirmPass')){
                $user->setPassword(
                    $passwordEncoder->encodePassword(
                        $user,
                        $request->request->get('pass')
                    ));
                    $manager->flush();
                    $this->addFlash('message','Mot de passe modifié avec succès');

                    return $this->redirectToRoute('adminsys_Profil');
            } else{
                $this->addFlash('error', 'Veuillez saisir deux mot de passe identiques');
            }
        }
        return $this->render('admin_sys/modifPass.html.twig');
    }     

    /**
     * @Route("/Creer_Compte", name="Create_Compte")
     */
    public function create(Request $request, EntityManagerInterface $manager){
        $compte =new Users();

        $form = $this->createFormBuilder($compte)
                     ->add('matricule')
                     ->add('nom')
                     ->add('prenom')
                     ->add('adresse')
                     ->add('email', EmailType::class)
                     ->add('telephone')
                     /*->add('Enregistrer', SubmitType::class, [
                         'label'=> 'Enregistrer'
                     ])*/
                     ->getForm();
        $form->handleRequest($request);
        
        dump($compte);
        
        if($form->isSubmitted() && $form->isValid()) {
            $compte->setStatusCompte('Actif');
            $compte->setMotDePasse('Passer');
            $compte->setRoles(["ROLE_MODER"]);
            $compte-setIdResp($this->getUser()->getId());
        }

        return $this->render('admin_sys/create.html.twig', [
            'formcreationca' => $form->createView()
        ]);
    }

    /**
     * Lister les comptes
     * @Route("/comptes", name="comptes")
     */
    public function usersList(UsersRepository $usersenfant){
        return $this->render("admin_sys/users.html.twig",[
            'users' => $usersenfant->findAll()
        ]);
    }

    /**
     * Supprimer Compte
     * @Route("/comptes/supprimer/{id}")
     */
    public function supprimer(Users $user){
        $em = $this->getDoctrine()->getManager();
        $em->remove($user);
        $em->flush();

        $this->addFlash('message', 'Compte supprimer avec succès');
        return $this->redirectToRoute('adminsys_comptes');
    }

    /**
     * Bloquer Compte
     * @Route("/comptes/bloquer/{id}")
     */
    public function bloquer(Users $user){
        if($user->getStatusCompte() == "Actif"){
        $user->setStatusCompte("Inactif"); }
        else {
            $user->setStatusCompte("Actif");
        }
        $em = $this->getDoctrine()->getManager();
        $em->persist($user);
        $em->flush();

        return new Response("true");
    }

}
