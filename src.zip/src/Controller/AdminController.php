<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Encoder\UserPasswordEncoderInterface;
use Symfony\Component\Routing\Annotation\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use App\Form\ModifProfilFormType;
use App\Repository\UsersRepository;
/**
 * @IsGranted("ROLE_ADMIN")
 * @Route("/admin", name="admin_")
 */
class AdminController extends AbstractController
{
    /**
     * @Route("/home", name="home")
     */
    public function home(){
        return $this->render('app/accueil.html.twig');        
    }

    /**
     * @Route("/Notifications", name="Notif")
     */
    public function notif(){
        return $this->render('admin/notif.html.twig');
    }

    /**
     * @Route("/Profil", name="Profil")
     */
    public function profil(){
        return $this->render('admin/profil.html.twig');
    }

    /**
     * @Route("/Compte_rendus", name="Cr")
     */
    public function cr() {
        return $this->render('admin/cr.html.twig');
    }

    
    /**
     * @Route("/Creer_CompteM", name="Create_CompteM")
     */
    public function create(Request $request, EntityManagerInterface $manager){
        $compte =new CompteAgent();

        $form = $this->createFormBuilder($compte)
                     ->add('matricule')
                     ->add('nom')
                     ->add('prenom')
                     ->add('adresse')
                     ->add('email', EmailType::class)
                     ->add('telephone')
                     /*->add('Enregistrer', SubmitType::class, [
                         'label'=> 'Enregistrer'
                     ])*/
                     ->getForm();
        $form->handleRequest($request);
        
        dump($compte);
        
        if($form->isSubmitted() && $form->isValid()) {
            $compte->setStatusCompte('Actif');
            $compte->setMotDePasse('Passer');
            $compte->setRoles(["ROLE_MODER"]);
            $compte-setIdResp($this->getUser()->getId());
        }

        return $this->render('admin/create.html.twig', [
            'formcreationca' => $form->createView()
        ]);
    }

    /**
     * Lister les comptes moderateurs
     * @Route("/moderateurs", name="moderateurs")
     */
    public function usersList(UsersRepository $usersenfant){
        $user = $this->getUser();
        return $this->render("admin/users.html.twig",[
            'users' => $usersenfant->findByIdResp($user->getId())
        ]);
    }

    /**
     * Modifier Profile
     * @Route("/Profil/Modifier_profil", name="modif_Pro")
     */
    public function modifPro(Request $request){
        $user = $this->getUser();
        $form = $this->createForm(ModifProfilFormType::class, $user);
                    /*->add('nom', TextType::class)
                    ->add('prenom', TextType::class)
                    ->add('adresse', EmailType::class)
                    ->add('telephone');*/
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
// encode the plain password
/*$user->setPassword(
    $passwordEncoder->encodePassword(
        $user,
        $form->get('plainPassword')->getData()
    )
);
$user->setStatusCompte('Actif');
$user->setRoles(["ROLE_AGENT"]);*/

            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($user);
            $entityManager->flush();
// do anything else you need here, like send an email

            $this->addFlash('message','Profil mis à jour');
            return $this->redirectToRoute('admin_Profil');
        }

        return $this->render('admin/modifpro.html.twig', [
            'modifForm' => $form->createView(),
            ]);
    }

    /**
     * Modifier Mot de passe
     * @Route("/Profil/Modifier_passe", name="modif_Pass")
     */
    public function modifPass(Request $request, UserPasswordEncoderInterface $passwordEncoder){
       if($request->isMethod('POST')){
            $manager = $this->getDoctrine()->getManager();

            $user = $this->getUser();

            if($request->request->get('pass') == $request->request->get('confirmPass')){
                $user->setPassword(
                    $passwordEncoder->encodePassword(
                        $user,
                        $request->request->get('pass')
                    ));
                    $manager->flush();
                    $this->addFlash('message','Mot de passe modifié avec succès');

                    return $this->redirectToRoute('admin_Profil');
            } else{
                $this->addFlash('error', 'Veuillez saisir deux mot de passe identiques');
            }
        }
        return $this->render('admin/modifPass.html.twig');
    }

}
