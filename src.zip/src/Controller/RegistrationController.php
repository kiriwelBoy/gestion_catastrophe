<?php

namespace App\Controller;

use App\Entity\Users;
use App\Form\RegistrationFormType;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Core\Encoder\UserPasswordEncoderInterface;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use App\Repository\UsersRepository;

class RegistrationController extends AbstractController
{
    /**
     * @Route("/Creer_Compte_Agent", name="app_register_agent")
     */
    public function registeragent(Request $request, UserPasswordEncoderInterface $passwordEncoder): Response
    {
        $this->denyAccessUnlessGranted('ROLE_MODER');
        $user = new Users();
        $form = $this->createForm(RegistrationFormType::class, $user)
                    ->add('matricule')
                    ->add('nom')
                    ->add('prenom')
                    ->add('adresse', EmailType::class)
                    ->add('telephone');
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // encode the plain password
            $user->setPassword(
                $passwordEncoder->encodePassword(
                    $user,
                    $form->get('Password')->getData()
                )
            );
            $user->setStatusCompte('Actif');
            //$user->setPassword('Passer');
            $user->setRoles(['ROLE_ADSYS']);
            //$user->setIdResp($this->getUser()->getId());

            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($user);
            $entityManager->flush();
            // do anything else you need here, like send an email

            return $this->redirectToRoute('app_register_agent');
        }

        return $this->render('registration/register.html.twig', [
            'registrationForm' => $form->createView(),
        ]);
    }

    /**
     * @Route("/Creer_Compte_Moder", name="app_register_moder")
     */
    public function registermoder(Request $request, UserPasswordEncoderInterface $passwordEncoder): Response
    {
        $this->denyAccessUnlessGranted('ROLE_ADMIN');
        $user = new Users();
        $form = $this->createForm(RegistrationFormType::class, $user)
                    ->add('matricule')
                    ->add('nom')
                    ->add('prenom')
                    ->add('adresse', EmailType::class)
                    ->add('telephone');
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // encode the plain password
            $user->setPassword(
                $passwordEncoder->encodePassword(
                    $user,
                    $form->get('Password')->getData()
                )
            );
            $user->setStatusCompte('Actif');
            $user->setRoles(["ROLE_MODER"]);

            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($user);
            $entityManager->flush();
            // do anything else you need here, like send an email

            return $this->redirectToRoute('Create_CompteM');
        }

        return $this->render('registration/register.html.twig', [
            'registrationForm' => $form->createView(),
        ]);
    }
    /**
     * @Route("/Creer_Compte_AdjComp", name="app_register_adjcomp")
     */
    public function registerAdjComp(Request $request, UserPasswordEncoderInterface $passwordEncoder, UsersRepository $usersenfant): Response
    {
        $this->denyAccessUnlessGranted('ROLE_ADSYS');
        $user = new Users();
        $form = $this->createForm(RegistrationFormType::class, $user)
                    ->add('matricule')
                    ->add('nom')
                    ->add('prenom')
                    ->add('adresse', EmailType::class)
                    ->add('telephone')
                    ->add('region');
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // encode the plain password
            $user->setPassword(
                $passwordEncoder->encodePassword(
                    $user,
                    $form->get('Password')->getData()
                )
            );
            $regmin= strtolower($user->getRegion());
            $user->setRegion($regmin);
            $user->setStatusCompte('Actif');
            $user->setRoles(["ROLE_ACOMP"]);
            $userrecup = $usersenfant->findByRegRole("ROLE_SCOMP",$regmin);
            //$userrecup->addUsers($users);
            foreach($userrecup as $users)
            {
                 $users->addUser($user);
                //$user->setIdResp($userrecup->getId());
            }
            //$userrecup->addUsers($user);
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($user);
            $entityManager->flush();
            // do anything else you need here, like send an email

            return $this->redirectToRoute('');
        }

        return $this->render('adj_comp/create.html.twig', [
            'registrationForm' => $form->createView(),
        ]);
    }

    /**
     * @Route("/Creer_Compte_SupComp", name="app_register_supcomp")
     */
    public function registerSupComp(Request $request, UserPasswordEncoderInterface $passwordEncoder, UsersRepository $usersenfant): Response
    {
        $this->denyAccessUnlessGranted('ROLE_ADSYS');
        $user = new Users();
        $form = $this->createForm(RegistrationFormType::class, $user)
                    ->add('matricule')
                    ->add('nom')
                    ->add('prenom')
                    ->add('adresse', EmailType::class)
                    ->add('telephone')
                    ->add('region');
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // encode the plain password
            $user->setPassword(
                $passwordEncoder->encodePassword(
                    $user,
                    $form->get('Password')->getData()
                )
            );
            $regmin= strtolower($user->getRegion());
            $user->setRegion($regmin);
            $user->setStatusCompte('Actif');
            $user->setRoles(["ROLE_SCOMP"]);
            $userrecup = $usersenfant->findByRegRole("ROLE_APREF",$regmin);
            //$userrecup->addUsers($users);
            foreach($userrecup as $users)
            {
                 $users->addUser($user);
                //$user->setIdResp($userrecup->getId());
            }
            //$userrecup->addUsers($user);
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($user);
            $entityManager->flush();
            // do anything else you need here, like send an email

            return $this->redirectToRoute('');
        }

        return $this->render('sup_comp/create.html.twig', [
            'registrationForm' => $form->createView(),
        ]);
    }    

    /**
     * @Route("/Creer_Compte_AdjPref", name="app_register_adjpref")
     */
    public function registerAdjPref(Request $request, UserPasswordEncoderInterface $passwordEncoder, UsersRepository $usersenfant): Response
    {
        $this->denyAccessUnlessGranted('ROLE_ADSYS');
        $user = new Users();
        $form = $this->createForm(RegistrationFormType::class, $user)
                    ->add('matricule')
                    ->add('nom')
                    ->add('prenom')
                    ->add('adresse', EmailType::class)
                    ->add('telephone')
                    ->add('region');
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // encode the plain password
            $user->setPassword(
                $passwordEncoder->encodePassword(
                    $user,
                    $form->get('Password')->getData()
                )
            );
            $regmin= strtolower($user->getRegion());
            $user->setRegion($regmin);
            $user->setStatusCompte('Actif');
            $user->setRoles(["ROLE_APREF"]);
            $userrecup = $usersenfant->findByRegRole("ROLE_PREF",$regmin);
            //$userrecup->addUsers($users);
            foreach($userrecup as $users)
            {
                 $users->addUser($user);
                //$user->setIdResp($userrecup->getId());
            }
            //$userrecup->addUsers($user);
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($user);
            $entityManager->flush();
            // do anything else you need here, like send an email

            return $this->redirectToRoute('');
        }

        return $this->render('adj_pref/create.html.twig', [
            'registrationForm' => $form->createView(),
        ]);
    }

    /**
     * @Route("/Creer_Compte_Pref", name="app_register_pref")
     */
    public function registerPref(Request $request, UserPasswordEncoderInterface $passwordEncoder, UsersRepository $usersenfant): Response
    {
        $this->denyAccessUnlessGranted('ROLE_ADSYS');
        $user = new Users();
        $form = $this->createForm(RegistrationFormType::class, $user)
                    ->add('matricule')
                    ->add('nom')
                    ->add('prenom')
                    ->add('adresse', EmailType::class)
                    ->add('telephone')
                    ->add('region');
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // encode the plain password
            $user->setPassword(
                $passwordEncoder->encodePassword(
                    $user,
                    $form->get('Password')->getData()
                )
            );
            $regmin= strtolower($user->getRegion());
            $user->setRegion($regmin);
            $user->setStatusCompte('Actif');
            $user->setRoles(["ROLE_PREF"]);
            $userrecup = $usersenfant->findByRegRole("ROLE_AGOUV",$regmin);
            //$userrecup->addUsers($users);
            foreach($userrecup as $users)
            {
                 $users->addUser($user);
                //$user->setIdResp($userrecup->getId());
            }
            //$userrecup->addUsers($user);
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($user);
            $entityManager->flush();
            // do anything else you need here, like send an email

            return $this->redirectToRoute('');
        }

        return $this->render('pref/create.html.twig', [
            'registrationForm' => $form->createView(),
        ]);
    }    

    /**
     * @Route("/Creer_Compte_AdjGouv", name="app_register_adjgouv")
     */
    public function registerAdjGouv(Request $request, UserPasswordEncoderInterface $passwordEncoder, UsersRepository $usersenfant): Response
    {
        $this->denyAccessUnlessGranted('ROLE_ADSYS');
        $user = new Users();
        $form = $this->createForm(RegistrationFormType::class, $user)
                    ->add('matricule')
                    ->add('nom')
                    ->add('prenom')
                    ->add('adresse', EmailType::class)
                    ->add('telephone')
                    ->add('region');
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // encode the plain password
            $user->setPassword(
                $passwordEncoder->encodePassword(
                    $user,
                    $form->get('Password')->getData()
                )
            );
            $regmin= strtolower($user->getRegion());
            $user->setRegion($regmin);
            $user->setStatusCompte('Actif');
            $user->setRoles(["ROLE_AGOUV"]);
            $userrecup = $usersenfant->findByRegRole("ROLE_GOUV",$regmin);
            //$userrecup->addUsers($users);
            foreach($userrecup as $users)
            {
                 $users->addUser($user);
                //$user->setIdResp($userrecup->getId());
            }
            //$userrecup->addUsers($user);
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($user);
            $entityManager->flush();
            // do anything else you need here, like send an email

            return $this->redirectToRoute('');
        }

        return $this->render('adj_gouv/create.html.twig', [
            'registrationForm' => $form->createView(),
        ]);
    }    

    /**
     * @Route("/Creer_Compte_Gouv", name="app_register_gouv")
     */
    public function registergouv(Request $request, UserPasswordEncoderInterface $passwordEncoder, UsersRepository $usersenfant): Response
    {
        $this->denyAccessUnlessGranted('ROLE_ADSYS');
        $user = new Users();
        $form = $this->createForm(RegistrationFormType::class, $user)
                    ->add('matricule')
                    ->add('nom')
                    ->add('prenom')
                    ->add('adresse', EmailType::class)
                    ->add('telephone')
                    ->add('region');
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // encode the plain password
            $user->setPassword(
                $passwordEncoder->encodePassword(
                    $user,
                    $form->get('Password')->getData()
                )
            );
            $user->setStatusCompte('Actif');
            $user->setRoles(["ROLE_GOUV"]);
            $userrecup = $usersenfant->findByRole("ROLE_CBUR");
            //$userrecup->addUsers($users);
            foreach($userrecup as $users)
            {
                 $users->addUser($user);
                //$user->setIdResp($userrecup->getId());
            }
            //$userrecup->addUsers($user);
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($user);
            $entityManager->flush();
            // do anything else you need here, like send an email

            return $this->redirectToRoute('');
        }

        return $this->render('gouv/create.html.twig', [
            'registrationForm' => $form->createView(),
        ]);
    }    

    /**
     * @Route("/Creer_Compte_ChefBur", name="app_register_chefbur")
     */
    public function registerChefBur(Request $request, UserPasswordEncoderInterface $passwordEncoder, UsersRepository $usersenfant): Response
    {
        $this->denyAccessUnlessGranted('ROLE_ADSYS');
        $user = new Users();
        $form = $this->createForm(RegistrationFormType::class, $user)
                    ->add('matricule')
                    ->add('nom')
                    ->add('prenom')
                    ->add('adresse', EmailType::class)
                    ->add('telephone')
                    ->add('region');
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // encode the plain password
            $user->setPassword(
                $passwordEncoder->encodePassword(
                    $user,
                    $form->get('Password')->getData()
                )
            );
            $user->setStatusCompte('Actif');
            $user->setRoles(["ROLE_CBUR"]);
           /*  $userrecup=$usersenfant->findOneby(/* array('region'=>$user->getRegion()), */ /*array('roles'=>["ROLE_DPC"])); */
            //$userrecup=$usersenfant->findByRoles(["ROLE_DPC"]);/*(* array('region'=>$user->getRegion()), * array('roles'=>["ROLE_DPC"]))->getId()); */
            $userrecup = $usersenfant->findByRole("ROLE_CDIV");
            //$userrecup->addUsers($users);
            foreach($userrecup as $users)
            {
                 $users->addUser($user);
                //$user->setIdResp($userrecup->getId());
            }
            //$userrecup->addUsers($user);
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($user);
            $entityManager->flush();
            // do anything else you need here, like send an email

            return $this->redirectToRoute('adminsys_home');
        }

        return $this->render('chef_bureau/create.html.twig', [
            'registrationForm' => $form->createView(),
        ]);
    }    

    /**
     * @Route("/Creer_Compte_Chef_Division", name="app_register_chefdivision")
     */
    public function registerChefDiv(Request $request, UserPasswordEncoderInterface $passwordEncoder, UsersRepository $usersenfant): Response
    {
        $this->denyAccessUnlessGranted('ROLE_ADSYS');
        $user = new Users();
        $form = $this->createForm(RegistrationFormType::class, $user)
                    ->add('matricule')
                    ->add('nom')
                    ->add('prenom')
                    ->add('adresse', EmailType::class)
                    ->add('telephone')
                    ->add('region');
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // encode the plain password
            $user->setPassword(
                $passwordEncoder->encodePassword(
                    $user,
                    $form->get('Password')->getData()
                )
            );
            $user->setStatusCompte('Actif');
            $user->setRoles(["ROLE_CDIV"]);
           /*  $userrecup=$usersenfant->findOneby(/* array('region'=>$user->getRegion()), */ /*array('roles'=>["ROLE_DPC"])); */
            //$userrecup=$usersenfant->findByRoles(["ROLE_DPC"]);/*(* array('region'=>$user->getRegion()), * array('roles'=>["ROLE_DPC"]))->getId()); */
            $userrecup = $usersenfant->findByRole("ROLE_DPC");
            //$userrecup->addUsers($users);
            foreach($userrecup as $users)
            {
                 $users->addUser($user);
                //$user->setIdResp($userrecup->getId());
            }
            //$userrecup->addUsers($user);
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($user);
            $entityManager->flush();
            // do anything else you need here, like send an email

            return $this->redirectToRoute('adminsys_home');
        }

        return $this->render('chef_div/create.html.twig', [
            'registrationForm' => $form->createView(),
        ]);
    }    

    /**
     * @Route("/Creer_Compte_Directeur_DPC", name="app_register_directeur")
     */
    public function registerdpc(Request $request, UserPasswordEncoderInterface $passwordEncoder): Response
    {
        $this->denyAccessUnlessGranted('ROLE_ADSYS');
        $user = new Users();
        $form = $this->createForm(RegistrationFormType::class, $user)
                    ->add('matricule')
                    ->add('nom')
                    ->add('prenom')
                    ->add('adresse', EmailType::class)
                    ->add('telephone')
                    ->add('region');
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // encode the plain password
            $user->setPassword(
                $passwordEncoder->encodePassword(
                    $user,
                    $form->get('Password')->getData()
                )
            );
            $user->setStatusCompte('Actif');
            $user->setRoles(["ROLE_DPC"]);

            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($user);
            $entityManager->flush();
            // do anything else you need here, like send an email

            return $this->redirectToRoute('adminsys_home');
        }

        return $this->render('sup_dpc/create.html.twig', [
            'registrationForm' => $form->createView(),
        ]);
    }    
    
}
