<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Encoder\UserPasswordEncoderInterface;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use App\Form\ModifProfilFormType;
use App\Entity\Accident;
use App\Entity\Incendie;
use App\Entity\Lieu;
use App\Form\IncendieType;
use App\Form\AccidentType;
use App\Form\CaracteristiquesTyoeType;
use App\Form\LieuType;
use Doctrine\ORM\EntityManagerInterface;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;

/**
 * @IsGranted("ROLE_AGENT")
 * @Route("/agent", name="agent_")
 */
class AgentController extends AbstractController
{
    /**
     * @Route("/home", name="home")
     */
    public function home()
    {
        return $this->render('app/accueil.html.twig');
    }

    /**
     * @Route("/Rediger_Cr_Accident", name="R_Cr_A")
     */
    public function rcr(EntityManagerInterface $entityManager, Request $request){

        $accident = new Accident();

        $form = $this->createForm(AccidentType::class, $accident);

        $form ->handleRequest($request);

        if($form->isSubmitted() && $form->isValid()){
            foreach ($accident->getVehicule() as $vehicule) {
                $vehicule->setAccident($accident);
                $entityManager->persist($vehicule);
            }
            foreach ($accident->getUsager() as $usager) {
                $usager->setAccident($accident);
                $entityManager->persist($usager);
            }
            foreach ($accident->getLieu() as $lieu) {
                $lieu->addAccidentsregistre($accident);
                $entityManager->persist($lieu);
            }

            $accident = $form->getData();
            $entityManager->persist($accident);
            $entityManager->flush();

            $this->addFlash(
                'success',
                "Le formulaire a bien été envoyé"
            );
            return $this->redirectToRoute('home');
        }   
        
        return $this->render('agent/rcra.html.twig',[
            'form'    => $form->createView()
        ]);
    }

    /**
     * @Route("/Rediger_Cr_Innondation", name="R_Cr_I")
     */
    public function rcri(){
        return $this->render('agent/rcri.html.twig');
    }

    /**
     * @Route("/Rediger_Cr_Incendie", name="R_Cr_In")
     */
    public function rcrin(EntityManagerInterface $entityManager, Request $request){
        $incedie = new Incendie();
                      
        $form = $this->createForm(IncendieType::class, $incedie);
        $form ->handleRequest($request);

        if($form->isSubmitted() && $form->isValid()){
            $incedie = $form->getData();
            $entityManager->persist($incedie);
            $entityManager->flush();
            $this->addFlash(
                'success',
                "Le formulaire a bien été envoyé"
            );
            return $this->redirectToRoute('home');
        }
        return $this->render('agent/rcrin.html.twig',[
            'form'             => $form->createView(),
        ]);
    }

    /**
     * @Route("/Compte_rendus", name="Cr")
     */
    public function cr(){
        $user = $this->getUser();
        $accident = $user->getAccidentsregis();
        return $this->render("agent/cr.html.twig",[
            'accidents' => $accident
        ]);
    }

    /**
     * @Route("/Notifications", name="Notif")
     */
    public function notif(){
        return $this->render('agent/notif.html.twig');
    }

    /**
     * @Route("/Profil", name="Profil")
     */
    public function profil(){
        return $this->render('agent/profil.html.twig');
    }

    /**
     * Modifier Profile
     * @Route("/Profil/Modifier_profil", name="modif_Pro")
     */
    public function modifPro(Request $request){
        $user = $this->getUser();
        $form = $this->createForm(ModifProfilFormType::class, $user);
                    /*->add('nom', TextType::class)
                    ->add('prenom', TextType::class)
                    ->add('adresse', EmailType::class)
                    ->add('telephone');*/
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
// encode the plain password
/*$user->setPassword(
    $passwordEncoder->encodePassword(
        $user,
        $form->get('plainPassword')->getData()
    )
);
$user->setStatusCompte('Actif');
$user->setRoles(["ROLE_AGENT"]);*/

            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($user);
            $entityManager->flush();
// do anything else you need here, like send an email

            $this->addFlash('message','Profil mis à jour');
            return $this->redirectToRoute('agent_Profil');
        }

        return $this->render('agent/modifpro.html.twig', [
            'modifForm' => $form->createView(),
            ]);
    }

    /**
     * Modifier Mot de passe
     * @Route("/Profil/Modifier_passe", name="modif_Pass")
     */
    public function modifPass(Request $request, UserPasswordEncoderInterface $passwordEncoder){
       if($request->isMethod('POST')){
            $manager = $this->getDoctrine()->getManager();

            $user = $this->getUser();

            if($request->request->get('pass') == $request->request->get('confirmPass')){
                $user->setPassword(
                    $passwordEncoder->encodePassword(
                        $user,
                        $request->request->get('pass')
                    ));
                    $manager->flush();
                    $this->addFlash('message','Mot de passe modifié avec succès');

                    return $this->redirectToRoute('agent_Profil');
            } else{
                $this->addFlash('error', 'Veuillez saisir deux mot de passe identiques');
            }
        }
        return $this->render('agent/modifPass.html.twig');
    }    
}
